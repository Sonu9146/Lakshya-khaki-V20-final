
package com.lakshyakhaki.app
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.Icons
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.database.FirebaseDatabase

import androidx.compose.foundation.shape.RoundedCornerShape
import android.Manifest
import android.app.*
import android.app.TimePickerDialog
import android.content.*
import android.content.ClipData
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.VideoView
import android.widget.MediaController
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.lakshyakhaki.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Url

private val Context.lakshyaDataStore by preferencesDataStore("lakshya_settings")
private val DAILY_MCQ_GOAL = intPreferencesKey("daily_mcq_goal")
private val DAILY_GROUND_GOAL = booleanPreferencesKey("daily_ground_goal")
private val REMINDER_ENABLED = booleanPreferencesKey("reminder_enabled")
private val REMINDER_HOUR = intPreferencesKey("reminder_hour")
private val REMINDER_MINUTE = intPreferencesKey("reminder_minute")
private val MISTAKE_IDS = stringSetPreferencesKey("mistake_ids")
private val LEADERBOARD_POINTS = intPreferencesKey("leaderboard_points")
private val DAILY_XP_GOAL = intPreferencesKey("daily_xp_goal")
private val PLANNER_DAYS = stringSetPreferencesKey("planner_days")
private val LEADERBOARD_NAME = stringPreferencesKey("leaderboard_name")
private val INTRO_SEEN = booleanPreferencesKey("intro_seen")
private val ONBOARDING_COMPLETE = booleanPreferencesKey("onboarding_complete")

private const val REMINDER_CHANNEL = "lakshya_reminders"
private const val REMINDER_REQUEST = 4101

private val db by lazy { AppDatabase.get(App.instance) }

class App : android.app.Application() {
    companion object { lateinit var instance: App }
    override fun onCreate() { super.onCreate(); instance = this }
}

private fun scheduleDailyReminder(context: Context, hour: Int, minute: Int) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, REMINDER_REQUEST, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
}

private fun cancelDailyReminder(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, REMINDER_REQUEST, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    alarm.cancel(pending)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(
                REMINDER_CHANNEL, "Lakshya Khaki Reminders", NotificationManager.IMPORTANCE_DEFAULT
            ))
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(context, REMINDER_CHANNEL)
        else Notification.Builder(context)
        manager.notify(
            REMINDER_REQUEST,
            n.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("लक्ष्य खाकी")
                .setContentText("आजची MCQ practice आणि Ground training check करा.")
                .setAutoCancel(true).build()
        )
    }
}



data class FirebaseBackendStatus(
    val signedIn: Boolean,
    val configured: Boolean
)

private fun firebaseBackendStatus(): FirebaseBackendStatus {
    val configured = try {
        FirebaseFirestore.getInstance()
        true
    } catch (_: Exception) {
        false
    }
    val signedIn = try {
        FirebaseAuth.getInstance().currentUser != null
    } catch (_: Exception) {
        false
    }
    return FirebaseBackendStatus(signedIn = signedIn, configured = configured)
}

data class CommunityReply(
    val id: String,
    val postId: String,
    val user: String,
    val text: String,
    val createdAt: Long
)

data class CommunityLike(
    val postId: String,
    val userId: String
)

data class CommunityPost(
    val id: Int,
    val user: String,
    val text: String,
    val likes: Int,
    val replies: Int
)

private val DEMO_COMMUNITY_POSTS = listOf(
    CommunityPost(1, "Lakshya_Khaki", "Police Bharti ची तयारी कशी चालली आहे? आजचा target share करा 💪", 24, 8),
    CommunityPost(2, "StudyWarrior", "Maths मध्ये Percentage chapter कोणाला difficult वाटतोय?", 17, 6),
    CommunityPost(3, "GroundRunner", "आज 1600m practice complete ✅ Consistency is the key!", 31, 10)
)

data class DailyAffair(
    val title: String,
    val source: String,
    val published: String,
    val link: String
)

private val DAILY_AFFAIR_FEEDS = listOf(
    "Maharashtra" to "https://news.google.com/rss/search?q=Maharashtra+India+news&hl=en-IN&gl=IN&ceid=IN:en",
    "India" to "https://news.google.com/rss/search?q=India+government+India+news&hl=en-IN&gl=IN&ceid=IN:en",
    "Sports" to "https://news.google.com/rss/search?q=India+sports+news&hl=en-IN&gl=IN&ceid=IN:en",
    "Science" to "https://news.google.com/rss/search?q=India+science+technology+news&hl=en-IN&gl=IN&ceid=IN:en"
)

private fun readRssTag(parser: XmlPullParser, tag: String): String {
    return try {
        if (parser.eventType == XmlPullParser.START_TAG && parser.name == tag) {
            parser.next()
            if (parser.eventType == XmlPullParser.TEXT) parser.text ?: "" else ""
        } else ""
    } catch (_: Exception) { "" }
}

private fun fetchDailyAffairs(): List<DailyAffair> {
    val all = mutableListOf<DailyAffair>()

    for ((_, feedUrl) in DAILY_AFFAIR_FEEDS) {
        try {
            val connection = URL(feedUrl).openConnection().apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "LakshyaKhaki/2.4 Android")
            }

            connection.getInputStream().use { input ->
                val parser = XmlPullParserFactory.newInstance().newPullParser()
                parser.setInput(input, "UTF-8")

                var event = parser.eventType
                var title = ""
                var source = ""
                var pubDate = ""
                var link = ""
                var insideItem = false

                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG) {
                        when (parser.name) {
                            "item" -> {
                                insideItem = true
                                title = ""
                                source = ""
                                pubDate = ""
                                link = ""
                            }
                            "title" -> if (insideItem) title = readRssTag(parser, "title")
                            "source" -> if (insideItem) source = readRssTag(parser, "source")
                            "pubDate" -> if (insideItem) pubDate = readRssTag(parser, "pubDate")
                            "link" -> if (insideItem) link = readRssTag(parser, "link")
                        }
                    } else if (event == XmlPullParser.END_TAG && parser.name == "item") {
                        if (title.isNotBlank() && link.isNotBlank()) {
                            all.add(DailyAffair(title.trim(), source.trim(), pubDate.trim(), link.trim()))
                        }
                        insideItem = false
                    }
                    event = parser.next()
                }
            }
        } catch (_: Exception) {
            // Other feeds can still load if one feed fails.
        }
    }

    return all.distinctBy { it.title.lowercase(Locale.getDefault()) }.take(30)
}

private fun openNews(context: Context, link: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(link)))
    } catch (_: Exception) {}
}

data class StudyTopic(val title: String, val subtitle: String, val bullets: List<String>)
data class Question(val category: String, val question: String, val options: List<String>, val answer: Int, val topic: String = category, val id: String = question.hashCode().toString(), val explanation: String = "योग्य उत्तर: ${options[answer]}")

private val studyTopics = listOf(
    StudyTopic("मराठी व्याकरण","संधी • समास • शब्दशक्ती • वाक्यरचना",
        listOf("संधीचे प्रकार आणि उदाहरणे","समासाचे प्रमुख प्रकार","शब्दांचे अर्थ व विरुद्धार्थी","वाक्यशुद्धी सराव")),
    StudyTopic("गणित","टक्केवारी • सरासरी • गुणोत्तर • संख्या",
        listOf("टक्केवारीची मूलभूत सूत्रे","सरासरी व गुणोत्तर","नफा-तोटा व साधे व्याज","संख्या मालिका सराव")),
    StudyTopic("GK / GS","महाराष्ट्र • भारत • सामान्य विज्ञान",
        listOf("महाराष्ट्र सामान्यज्ञान","भारतीय राज्यघटना basics","दैनंदिन विज्ञान","महत्त्वाचे दिवस व तथ्ये")),
    StudyTopic("Reasoning","Series • Coding • Ranking • Analogy",
        listOf("अक्षर व संख्या मालिका","Coding-Decoding","क्रमांक व दिशा","साम्य व वर्गीकरण"))
)



data class MathsSyllabusTopic(val no: Int, val title: String, val english: String, val types: List<String>)

private val mathsSyllabus = listOf(
    MathsSyllabusTopic(1, "संख्या", "Numbers", listOf(
        "नैसर्गिक संख्या (Natural Numbers)", "पूर्णांक संख्या (Integers)", "विषम संख्या (Odd Numbers)", "चौरस संख्या (Square Numbers)",
        "षट्कोनी संख्या (Hexagonal Numbers)", "संयुक्त संख्या (Composite Numbers)", "जोडमूळ संख्या (Twin-Prime Numbers)", "अपरिमेय संख्या (Irrational Numbers)",
        "विरुद्ध संख्या (Opposite Numbers)", "परिपूर्ण संख्या (Complete Numbers)", "पूर्ण संख्या (Whole Numbers)", "सम संख्या (Even Numbers)",
        "त्रिकोणी संख्या (Triangular Numbers)", "पंचकोनी संख्या (Pentagonal Numbers)", "मूळ संख्या (Prime Numbers)", "सहमूळ संख्या (Co-prime Numbers)",
        "परिमेय संख्या (Rational Numbers)", "वास्तव संख्या (Real Numbers)", "अखंड संख्या (Continuous Numbers)", "गुणाकार व्यस्त संख्या (Multiplication Numbers)",
        "बेरीज-वजाबाकीचे नियम (Rules of Addition & Subtraction)", "बेरीज व वजाबाकी (Addition-Subtraction)", "गुणाकार (Multiplication)", "भागाकार (Division)",
        "लहान-मोठी संख्या तयार करणे (Smaller & Greater Numbers)", "संख्यांची तुलना (Comparison)", "कसोट्या (Tests)", "स्थानीय किंमत (Place Value)", "दर्शनी किंमत (Face Value)"
    )),
    MathsSyllabusTopic(2, "अपूर्णांक", "Fractions", listOf(
        "व्यवहारी अपूर्णांक (Vulgar Fraction)", "दशांश अपूर्णांक (Decimal Fraction)", "अंशाधिक अपूर्णांक (Improper Fraction)", "छेदाधिक अपूर्णांक (Proper Fraction)",
        "मिश्र अपूर्णांक / पूर्णांकयुक्त अपूर्णांक (Mixed / Integrally Fraction)", "एकक अपूर्णांक (Unit Fraction)", "अखंड अपूर्णांक (Continued Fraction)",
        "समछेद अपूर्णांक (Like Fraction)", "जटील / समिश्र अपूर्णांक (Complex Fraction)", "सममूल्य अपूर्णांक (Equivalent Fraction)",
        "Type-1: पूर्णांकयुक्त अपूर्णांकाचे मिश्र अपूर्णांकात रूपांतर", "Type-2: पूर्णांकयुक्त अपूर्णांकाचे साध्या अपूर्णांकात रूपांतर",
        "Type-3: सममूल्य अपूर्णांक", "Type-4: समान छेदाच्या अपूर्णांकांची बेरीज-वजाबाकी", "Type-5: असमान छेदाच्या अपूर्णांकांची बेरीज",
        "Type-6: तीन/अधिक अपूर्णांकांची बेरीज", "Type-7: बेरीज-वजाबाकीचे मिश्र उदाहरण"
    )),
    MathsSyllabusTopic(3, "रेखेमागुवेब (VBODMAS)", "VBODMAS", listOf("Vinculum / बार", "Brackets / कंस", "Of / चा-ची-चे", "Division / भागाकार", "Multiplication / गुणाकार", "Addition / बेरीज", "Subtraction / वजाबाकी")),
    MathsSyllabusTopic(4, "लसावी मसावी", "LCM & HCF", listOf("लसावी (LCM)", "मसावी (HCF)", "अवयव पद्धत", "भागाकार पद्धत", "LCM-HCF आधारित प्रश्न")),
    MathsSyllabusTopic(5, "सरासरी", "Average", listOf("साधी सरासरी", "एकूणावरून सरासरी", "सरासरीवरून एकूण", "नवीन संख्या जोडणे/काढणे", "संयुक्त सरासरी")),
    MathsSyllabusTopic(6, "घातांक", "Indices", listOf("घाताची मूलभूत संकल्पना", "घातांकाचे नियम", "ऋण घातांक", "शून्य घातांक", "घातांवरील उदाहरणे")),
    MathsSyllabusTopic(7, "वर्ग व वर्गमूळ", "Square & Square Root", listOf("वर्ग", "वर्गमूळ", "पूर्ण वर्ग संख्या", "वर्गमूळाची भागाकार पद्धत", "वर्गमूळावरील उदाहरणे")),
    MathsSyllabusTopic(8, "करणी", "Surds", listOf("करणीची ओळख", "करणीचे साधीकरण", "समान करणी", "करणींची बेरीज-वजाबाकी", "करणींचा गुणाकार/भागाकार")),
    MathsSyllabusTopic(9, "शेकडेवारी", "Percentage", listOf("टक्केवारीचे रूपांतर", "टक्केवारीतील वाढ", "टक्केवारीतील घट", "एकापेक्षा अधिक टक्केवारी", "टक्केवारीवरील शब्दसमस्या")),
    MathsSyllabusTopic(10, "नफा-तोटा", "Loss & Profit", listOf("खरेदी किंमत (CP)", "विक्री किंमत (SP)", "नफा", "तोटा", "नफा/तोटा टक्केवारी")),
    MathsSyllabusTopic(11, "सरळव्याज", "Simple Interest", listOf("मुद्दल", "दर", "कालावधी", "सरळव्याज", "रक्कम (Amount)")),
    MathsSyllabusTopic(12, "चक्रवाढव्याज", "Compound Interest", listOf("वार्षिक चक्रवाढ", "सहामाही/त्रैमासिक चक्रवाढ", "चक्रवाढ रक्कम", "सरळव्याज व चक्रवाढव्याज तुलना")),
    MathsSyllabusTopic(13, "सरळव्याज + चक्रवाढव्याज", "SI + CI", listOf("SI आधारित प्रश्न", "CI आधारित प्रश्न", "SI-CI मधील फरक", "मिश्र व्याज प्रश्न")),
    MathsSyllabusTopic(14, "सूट, कमिशन व दलाली", "Discount, Commission & Brokerage", listOf("अंकित किंमत", "सूट", "सूट टक्केवारी", "कमिशन", "दलाली")),
    MathsSyllabusTopic(15, "रेल्वे", "Train", listOf("वेग-अंतर-वेळ", "रेल्वे व खांब", "रेल्वे व प्लॅटफॉर्म", "दोन रेल्वे", "विरुद्ध/समान दिशेतील वेग")),
    MathsSyllabusTopic(16, "कार्य", "Work", listOf("कामाचे एकक", "एकट्याचे काम", "एकत्रित काम", "दिवस-क्षमता", "कार्यक्षमता")),
    MathsSyllabusTopic(17, "नळ व टाकी", "Pipes & Cisterns", listOf("भरणारा नळ", "रिकामा करणारा नळ", "एकत्रित नळ", "टाकी भरण्याचा वेळ", "उघडणे-बंद करणे")),
    MathsSyllabusTopic(18, "बोट व प्रवाह", "Boat & Streams", listOf("स्थिर पाण्यातील वेग", "प्रवाहाचा वेग", "प्रवाहाच्या दिशेने", "प्रवाहाविरुद्ध", "नौकेचा एकूण प्रवास")),
    MathsSyllabusTopic(19, "वय", "Age", listOf("वर्तमान वय", "भूतकाळातील वय", "भविष्यातील वय", "वयांची बेरीज/फरक", "वयाचे गुणोत्तर")),
    MathsSyllabusTopic(20, "गुणोत्तर व प्रमाण", "Ratio & Proportion", listOf("गुणोत्तर", "समप्रमाण", "व्यस्त प्रमाण", "संयुक्त प्रमाण", "गुणोत्तरावरील शब्दसमस्या")),
    MathsSyllabusTopic(21, "मिश्रण", "Alligation or Mixture", listOf("मिश्रणाचे गुणोत्तर", "सरासरी किंमत", "Alligation Rule", "दोन घटकांचे मिश्रण", "मिश्रणातील प्रमाण")),
    MathsSyllabusTopic(22, "मांडणी व निवड", "Permutation & Combinations", listOf("मांडणी (Permutation)", "निवड (Combination)", "nPr", "nCr", "सराव उदाहरणे")),
    MathsSyllabusTopic(23, "भागीदारी", "Partnership", listOf("भांडवलाचे गुणोत्तर", "वेळेनुसार भागीदारी", "नफा वाटप", "तोटा वाटप", "भागीदारीतील बदल")),
    MathsSyllabusTopic(24, "श्रेणी", "Progression", listOf("अंकगणित श्रेणी (AP)", "AP मधील पद", "AP ची बेरीज", "भूमितीय श्रेणी (GP)", "श्रेणीवरील प्रश्न")),
    MathsSyllabusTopic(25, "क्षेत्रफळ", "Area", listOf("चौरस", "आयत", "त्रिकोण", "समांतरभुज", "समलंब चौकोन", "वर्तुळ")),
    MathsSyllabusTopic(26, "घनफळ", "Volume", listOf("घन", "घनाभ", "बेलन", "शंकू", "गोल", "घनफळावरील रूपांतरे")),
    MathsSyllabusTopic(27, "दशमान पद्धतीची विविध परिमाणे", "Measurements", listOf("लांबी", "वजन", "क्षमता", "वेळ", "क्षेत्रफळ/घनफळ रूपांतरे")),
    MathsSyllabusTopic(28, "संख्याशास्त्र", "Statistics", listOf("माहिती/आकडेवारी", "वारंवारता", "सरासरी", "मध्यक (Median)", "बहुलक (Mode)", "तक्ते व आलेख")),
    MathsSyllabusTopic(29, "त्रिकोणमिती", "Trigonometry", listOf("sin", "cos", "tan", "त्रिकोणमितीय गुणोत्तर", "उंची व अंतर")),
    MathsSyllabusTopic(30, "चलन", "Variation", listOf("सरळ चलन", "व्यस्त चलन", "संयुक्त चलन", "चलनातील गुणोत्तर")),
    MathsSyllabusTopic(31, "शेअर्स", "Shares", listOf("शेअरचे दर्शनी मूल्य", "बाजारमूल्य", "लाभांश", "लाभांश टक्केवारी", "प्रीमियम/डिस्काउंट")),
    MathsSyllabusTopic(32, "बीजगणितीय राशी व त्यावरील क्रिया", "Algebraic Expressions", listOf("पद व गुणांक", "समान पदे", "बेरीज", "वजाबाकी", "गुणाकार")),
    MathsSyllabusTopic(33, "बहुपदी", "Polynomials", listOf("एकपदी", "द्विपदी", "त्रिपदी", "बहुपदीची बेरीज-वजाबाकी", "बहुपदीचा गुणाकार")),
    MathsSyllabusTopic(34, "गुणोत्तरीय बीजगणितीय राशी", "Algebraic Ratios", listOf("बीजगणितीय गुणोत्तर", "गुणोत्तराचे साधीकरण", "प्रमाण", "चल असलेले गुणोत्तर")),
    MathsSyllabusTopic(35, "एकसामायिक समीकरणे", "Simultaneous Equations", listOf("दोन चलांची समीकरणे", "विलोपन पद्धत", "प्रतिस्थापन पद्धत", "समीकरणांचा संयुक्त उपयोग")),
    MathsSyllabusTopic(36, "रेषीय समीकरणे", "Linear Equations", listOf("एक चलातील रेषीय समीकरण", "कंस असलेली समीकरणे", "अपूर्णांक असलेली समीकरणे", "शब्दसमस्या")),
    MathsSyllabusTopic(37, "नित्य समीकरणे", "Identities", listOf("(a+b)²", "(a-b)²", "a²-b²", "(a+b+c)²", "ओळख वापरून साधीकरण")),
    MathsSyllabusTopic(38, "एकचल समीकरणे", "Equations in One Variable", listOf("साधी समीकरणे", "कंसयुक्त समीकरणे", "अपूर्णांक समीकरणे", "शब्दसमस्या")),
    MathsSyllabusTopic(39, "वर्गसमीकरणे", "Quadratic Equations", listOf("वर्गसमीकरणाची ओळख", "घटक पद्धत", "मुळांचा शोध", "वर्गसमीकरणावरील उदाहरणे")),
    MathsSyllabusTopic(40, "भूमितीचे मूलभूत संबंध", "Basic Geometry", listOf("बिंदू व रेषा", "कोन", "कोनांचे प्रकार", "रेषाखंड", "भूमितीय मूलभूत संकल्पना")),
    MathsSyllabusTopic(41, "समांतर रेषा", "Parallel Lines", listOf("समांतर रेषा", "छेदिका", "संगत कोन", "पर्यायी कोन", "अंतर्गत कोन")),
    MathsSyllabusTopic(42, "त्रिकोण व त्रिकोणाचे प्रकार", "Types of Triangles", listOf("समभुज", "समद्विबाहु", "विषमभुज", "काटकोन", "न्यूनकोन", "अधिककोन")),
    MathsSyllabusTopic(43, "चौकोन", "Quadrilateral", listOf("चौरस", "आयत", "समांतरभुज चौकोन", "समलंब चौकोन", "समभुज चौकोन")),
    MathsSyllabusTopic(44, "पायथागोरस प्रमेय", "Pythagoras Theorem", listOf("काटकोन त्रिकोण", "कर्ण", "पायथागोरस सूत्र", "अज्ञात बाजू शोधणे", "पायथागोरस त्रिकूट")),
    MathsSyllabusTopic(45, "वर्तुळ", "Circle", listOf("त्रिज्या", "व्यास", "जीवा", "चाप", "परिघ", "वर्तुळाचे क्षेत्रफळ")),
    MathsSyllabusTopic(46, "निर्देशक भूमिती", "Co-ordinate Geometry", listOf("निर्देशक अक्ष", "X-अक्ष", "Y-अक्ष", "बिंदूचे निर्देशांक", "चतुर्थांश", "दोन बिंदूंमधील अंतर"))
)

data class GkSyllabusTopic(val no: Int, val title: String, val english: String, val types: List<String>)

private val gkGsSyllabus = listOf(
    GkSyllabusTopic(1, "महाराष्ट्र सामान्यज्ञान", "Maharashtra GK", listOf("महाराष्ट्राचा इतिहास", "महाराष्ट्राचा भूगोल", "जिल्हे व विभाग", "नद्या, धरणे व तलाव", "पर्वतरांगा व शिखरे", "राष्ट्रीय उद्याने व अभयारण्ये", "महत्त्वाची शहरे", "लोककला, संस्कृती व सण", "संत व समाजसुधारक", "महत्त्वाची ठिकाणे व संस्था")),
    GkSyllabusTopic(2, "भारतीय इतिहास", "Indian History", listOf("प्राचीन भारत", "वैदिक काळ", "मौर्य व गुप्त काळ", "मध्ययुगीन भारत", "दिल्ली सल्तनत", "मुघल काळ", "मराठा साम्राज्य", "ब्रिटिश काळ", "स्वातंत्र्य चळवळ", "महत्त्वाच्या ऐतिहासिक घटना")),
    GkSyllabusTopic(3, "महाराष्ट्राचा इतिहास", "History of Maharashtra", listOf("छत्रपती शिवाजी महाराज", "स्वराज्याची स्थापना", "अष्टप्रधान मंडळ", "संभाजी महाराज", "पेशवे काळ", "मराठा साम्राज्याचा विस्तार", "सामाजिक व धार्मिक सुधारणा", "स्वातंत्र्य चळवळीतील महाराष्ट्र", "महत्त्वाच्या व्यक्ती", "ऐतिहासिक किल्ले")),
    GkSyllabusTopic(4, "भारतीय राज्यघटना", "Indian Constitution", listOf("संविधान निर्मिती", "प्रस्तावना", "मूलभूत अधिकार", "मूलभूत कर्तव्ये", "राज्याच्या मार्गदर्शक तत्त्वे", "राष्ट्रपती व उपराष्ट्रपती", "पंतप्रधान व मंत्रिमंडळ", "संसद", "सर्वोच्च न्यायालय", "राज्य शासन", "घटनात्मक संस्था")),
    GkSyllabusTopic(5, "राज्यशास्त्र व प्रशासन", "Polity & Administration", listOf("केंद्र शासन", "राज्य शासन", "लोकसभा व राज्यसभा", "निवडणूक आयोग", "केंद्र-राज्य संबंध", "स्थानिक स्वराज्य संस्था", "महानगरपालिका व नगरपालिका", "ग्रामपंचायत, पंचायत समिती व जिल्हा परिषद", "प्रशासकीय रचना", "लोकशाही व्यवस्था")),
    GkSyllabusTopic(6, "भारताचा भूगोल", "Indian Geography", listOf("स्थान व सीमा", "भौगोलिक रचना", "हिमालय", "मैदाने व पठारे", "नद्या व नदीखोरे", "हवामान", "मृदा", "शेती व पिके", "खनिजे व ऊर्जा", "उद्योग", "वाहतूक")),
    GkSyllabusTopic(7, "महाराष्ट्राचा भूगोल", "Geography of Maharashtra", listOf("स्थान व सीमा", "सह्याद्री व पर्वतरांगा", "नद्या व खोरे", "कोकण, पश्चिम महाराष्ट्र, मराठवाडा व विदर्भ", "मृदा व हवामान", "पिके व शेती", "खनिजे", "उद्योग", "धरणे व सिंचन", "वनसंपदा व अभयारण्ये")),
    GkSyllabusTopic(8, "भारतीय अर्थव्यवस्था", "Indian Economy", listOf("अर्थव्यवस्थेच्या मूलभूत संकल्पना", "राष्ट्रीय उत्पन्न", "GDP व GNP", "महागाई", "बेरोजगारी", "बँकिंग", "RBI", "कर व्यवस्था", "अर्थसंकल्प", "सरकारी योजना", "आर्थिक संस्था")),
    GkSyllabusTopic(9, "महाराष्ट्राची अर्थव्यवस्था", "Maharashtra Economy", listOf("राज्याचे उत्पन्न", "कृषी अर्थव्यवस्था", "उद्योग", "सेवा क्षेत्र", "सहकार क्षेत्र", "महाराष्ट्राचा अर्थसंकल्प", "राज्याच्या योजना", "रोजगार व कौशल्य विकास", "पायाभूत सुविधा", "आर्थिक निर्देशांक")),
    GkSyllabusTopic(10, "सामान्य विज्ञान", "General Science", listOf("विज्ञानाची मूलतत्त्वे", "मापन व एकके", "पदार्थ व त्यांचे गुणधर्म", "ऊर्जा", "उष्णता", "प्रकाश", "ध्वनी", "वीज", "चुंबकत्व", "दैनंदिन जीवनातील विज्ञान")),
    GkSyllabusTopic(11, "जीवशास्त्र व मानवी शरीर", "Biology & Human Body", listOf("पेशी", "मानवी अवयव", "पचनसंस्था", "श्वसनसंस्था", "रक्ताभिसरण", "मज्जासंस्था", "अंतःस्रावी ग्रंथी", "हाडे व स्नायू", "जीवनसत्त्वे व खनिजे", "सामान्य रोग व प्रतिबंध")),
    GkSyllabusTopic(12, "भौतिकशास्त्र", "Physics", listOf("गती", "बल व न्यूटनचे नियम", "काम, ऊर्जा व शक्ती", "गुरुत्वाकर्षण", "दाब", "उष्णता", "प्रकाश", "ध्वनी", "वीज", "चुंबकत्व")),
    GkSyllabusTopic(13, "रसायनशास्त्र", "Chemistry", listOf("पदार्थाच्या अवस्था", "अणू व रेणू", "मूलद्रव्ये व संयुगे", "आम्ल, आम्लारी व क्षार", "धातू व अधातू", "रासायनिक अभिक्रिया", "मिश्रणे", "कार्बन संयुगे", "दैनंदिन जीवनातील रसायनशास्त्र", "पर्यावरणीय रसायनशास्त्र")),
    GkSyllabusTopic(14, "पर्यावरण व परिसंस्था", "Environment & Ecology", listOf("परिसंस्था", "अन्नसाखळी व अन्नजाळे", "जैवविविधता", "वनसंपदा", "प्रदूषण", "हवामान बदल", "जागतिक तापमानवाढ", "ओझोन थर", "संवर्धन", "राष्ट्रीय उद्याने व अभयारण्ये")),
    GkSyllabusTopic(15, "अंतराळ व खगोलशास्त्र", "Space & Astronomy", listOf("सूर्यमाला", "ग्रह व उपग्रह", "तारे", "आकाशगंगा", "ग्रहणे", "अंतराळ संशोधन", "भारतीय अंतराळ कार्यक्रम", "उपग्रह", "ISRO", "महत्त्वाच्या अंतराळ मोहिमा")),
    GkSyllabusTopic(16, "संगणक व तंत्रज्ञान", "Computer & Technology", listOf("संगणकाची मूलतत्त्वे", "हार्डवेअर", "सॉफ्टवेअर", "ऑपरेटिंग सिस्टम", "इंटरनेट", "नेटवर्किंग", "सायबर सुरक्षा", "डेटाबेस", "कृत्रिम बुद्धिमत्ता", "डिजिटल पेमेंट व तंत्रज्ञान")),
    GkSyllabusTopic(17, "क्रीडा", "Sports GK", listOf("ऑलिम्पिक", "आशियाई क्रीडा", "कॉमनवेल्थ गेम्स", "क्रिकेट", "फुटबॉल", "हॉकी", "टेनिस", "अॅथलेटिक्स", "महत्त्वाच्या स्पर्धा", "खेळाडू व विक्रम")),
    GkSyllabusTopic(18, "पुरस्कार व सन्मान", "Awards & Honours", listOf("भारतरत्न", "पद्म पुरस्कार", "राष्ट्रीय क्रीडा पुरस्कार", "नोबेल पुरस्कार", "ज्ञानपीठ पुरस्कार", "दादासाहेब फाळके पुरस्कार", "साहित्यिक पुरस्कार", "आंतरराष्ट्रीय पुरस्कार", "महत्त्वाचे सन्मान", "पुरस्कार विजेते")),
    GkSyllabusTopic(19, "पुस्तके व लेखक", "Books & Authors", listOf("भारतीय लेखक", "मराठी लेखक", "प्रसिद्ध पुस्तके", "आत्मचरित्रे", "चरित्रे", "साहित्यिक कृती", "पुरस्कारप्राप्त पुस्तके", "महत्त्वाचे लेखक")),
    GkSyllabusTopic(20, "कला व संस्कृती", "Art & Culture", listOf("शास्त्रीय नृत्य", "लोकनृत्य", "संगीत", "चित्रकला", "नाट्यकला", "लोककला", "भारतीय सण", "महाराष्ट्राची संस्कृती", "हस्तकला", "सांस्कृतिक वारसा")),
    GkSyllabusTopic(21, "राष्ट्रीय चिन्हे", "National Symbols", listOf("राष्ट्रीय ध्वज", "राष्ट्रीय चिन्ह", "राष्ट्रगीत", "राष्ट्रीय गीत", "राष्ट्रीय प्राणी", "राष्ट्रीय पक्षी", "राष्ट्रीय फूल", "राष्ट्रीय वृक्ष", "राष्ट्रीय नदी", "राष्ट्रीय दिन")),
    GkSyllabusTopic(22, "महत्त्वाचे दिवस", "Important Days", listOf("राष्ट्रीय दिवस", "आंतरराष्ट्रीय दिवस", "विज्ञान व तंत्रज्ञान दिवस", "पर्यावरण दिवस", "आरोग्य दिवस", "महिला व बालकांशी संबंधित दिवस", "लोकशाही व संविधानाशी संबंधित दिवस", "क्रीडा दिवस")),
    GkSyllabusTopic(23, "देश, राजधानी व चलने", "Countries, Capitals & Currencies", listOf("आशिया", "युरोप", "आफ्रिका", "उत्तर अमेरिका", "दक्षिण अमेरिका", "ऑस्ट्रेलिया व ओशिनिया", "प्रमुख राजधानी", "प्रमुख चलने", "भारताचे शेजारी देश", "आंतरराष्ट्रीय संस्थांची मुख्यालये")),
    GkSyllabusTopic(24, "आंतरराष्ट्रीय संस्था", "International Organizations", listOf("UNO", "WHO", "UNESCO", "UNICEF", "IMF", "World Bank", "WTO", "SAARC", "ASEAN", "G20", "BRICS")),
    GkSyllabusTopic(25, "सरकारी योजना", "Government Schemes", listOf("केंद्र सरकारच्या योजना", "महाराष्ट्र शासनाच्या योजना", "शिक्षण योजना", "आरोग्य योजना", "शेतकरी योजना", "महिला व बालकल्याण योजना", "रोजगार व कौशल्य योजना", "सामाजिक सुरक्षा योजना")),
    GkSyllabusTopic(26, "महत्त्वाच्या व्यक्ती व पदे", "Important Persons & Posts", listOf("राष्ट्रपती", "उपराष्ट्रपती", "पंतप्रधान", "राज्यपाल", "मुख्यमंत्री", "न्यायव्यवस्था", "वैज्ञानिक", "समाजसुधारक", "क्रीडापटू", "कलावंत")),
    GkSyllabusTopic(27, "विविध सामान्यज्ञान", "Miscellaneous GK", listOf("प्रथम भारतीय", "प्रथम महिला", "सर्वात मोठे/लहान", "उपनामे", "महत्त्वाची ठिकाणे", "महत्त्वाच्या संस्था", "रेकॉर्ड्स व तथ्ये", "वाहतूक व बंदरे", "भारतीय संरक्षण", "विविध स्थिर सामान्यज्ञान")),
    GkSyllabusTopic(28, "चालू घडामोडी", "Current Affairs", listOf("महाराष्ट्र", "भारत", "आंतरराष्ट्रीय", "क्रीडा", "पुरस्कार व नियुक्त्या", "विज्ञान व तंत्रज्ञान", "अर्थव्यवस्था", "सरकारी योजना", "महत्त्वाच्या घटना", "पर्यावरण"))
)

private val questions = listOf(
    // Marathi
    Question("मराठी","‘रामाने आंबा खाल्ला.’ या वाक्यातील कर्ता कोणता?",listOf("रामाने","आंबा","खाल्ला","या"),0,"वाक्यरचना"),
    Question("मराठी","‘सुंदर’ या शब्दाचा विरुद्धार्थी शब्द कोणता?",listOf("कुरूप","मोठा","गोड","लहान"),0,"शब्दसंपदा"),
    Question("मराठी","‘राजपुत्र’ हा कोणत्या समासाचा प्रकार आहे?",listOf("द्वंद्व","तत्पुरुष","बहुव्रीही","अव्ययीभाव"),1,"समास"),
    Question("मराठी","‘मी शाळेत जातो.’ या वाक्यातील क्रियापद कोणते?",listOf("मी","शाळेत","जातो","या"),2,"वाक्यरचना"),
    Question("मराठी","‘देव + आलय’ यांचा संधीयोग कोणता?",listOf("देवालय","देवाआलय","देवालयी","देवाल्य"),0,"संधी"),
    Question("मराठी","‘आई’ या शब्दाचे अनेकवचन कोणते?",listOf("आईं","आईया","आया","आई"),2,"शब्दसंपदा"),
    Question("मराठी","‘हात धुऊन मागे लागणे’ या वाक्प्रचाराचा अर्थ काय?",listOf("मदत करणे","पाठलाग करणे","हात धुणे","काम थांबवणे"),1,"वाक्प्रचार"),
    Question("मराठी","‘जो अभ्यास करतो तो यशस्वी होतो.’ हे कोणत्या प्रकारचे वाक्य आहे?",listOf("केवल","संयुक्त","मिश्र","उद्गारार्थी"),2,"वाक्यरचना"),

    // Maths
    Question("गणित","25% of 240 किती?",listOf("40","50","60","80"),2,"टक्केवारी"),
    Question("गणित","15 × 8 − 20 = ?",listOf("90","100","110","120"),1,"मूलभूत गणित"),
    Question("गणित","एका संख्येचा 3/5 भाग 36 आहे. संख्या किती?",listOf("48","60","72","90"),1,"अपूर्णांक"),
    Question("गणित","2, 6, 12, 20, 30, ? पुढील संख्या कोणती?",listOf("40","42","44","46"),1,"संख्या मालिका"),
    Question("गणित","एका वस्तूची किंमत ₹500 आहे. 10% सवलतीनंतर किंमत किती?",listOf("₹440","₹450","₹460","₹475"),1,"टक्केवारी"),
    Question("गणित","12 आणि 18 यांचा म.सा.वि. किती?",listOf("3","6","9","12"),1,"संख्या"),
    Question("गणित","4 कामगार एखादे काम 12 दिवसांत करतात. समान वेगाने 8 कामगार किती दिवस घेतील?",listOf("3","6","8","10"),1,"काम व वेळ"),
    Question("गणित","60 किमी/तास वेगाने 2 तासांत किती अंतर पार होईल?",listOf("100 किमी","120 किमी","140 किमी","160 किमी"),1,"वेग-अंतर-वेळ"),

    // GK/GS
    Question("GK/GS","महाराष्ट्राची राजधानी कोणती?",listOf("मुंबई","पुणे","नागपूर","नाशिक"),0,"महाराष्ट्र GK"),
    Question("GK/GS","भारताचा राष्ट्रीय प्राणी कोणता?",listOf("सिंह","वाघ","हत्ती","मोर"),1,"भारत GK"),
    Question("GK/GS","पाण्याचे रासायनिक सूत्र कोणते?",listOf("CO₂","O₂","H₂O","NaCl"),2,"सामान्य विज्ञान"),
    Question("GK/GS","भारतीय संविधानाचा स्वीकार कोणत्या दिवशी झाला?",listOf("15 ऑगस्ट 1947","26 नोव्हेंबर 1949","26 जानेवारी 1950","2 ऑक्टोबर 1950"),1,"भारतीय राज्यघटना"),
    Question("GK/GS","महाराष्ट्र दिन कोणत्या दिवशी साजरा केला जातो?",listOf("1 मे","15 ऑगस्ट","26 जानेवारी","2 ऑक्टोबर"),0,"महाराष्ट्र GK"),
    Question("GK/GS","सूर्याच्या सर्वात जवळचा ग्रह कोणता?",listOf("शुक्र","पृथ्वी","बुध","मंगळ"),2,"सामान्य विज्ञान"),
    Question("GK/GS","भारतीय संविधानाचे शिल्पकार म्हणून कोणाला ओळखले जाते?",listOf("महात्मा गांधी","डॉ. बाबासाहेब आंबेडकर","लोकमान्य टिळक","सुभाषचंद्र बोस"),1,"भारतीय राज्यघटना"),
    Question("GK/GS","रक्ताचा लाल रंग कोणत्या घटकामुळे असतो?",listOf("कॅल्शियम","हिमोग्लोबिन","प्लाझ्मा","इन्सुलिन"),1,"सामान्य विज्ञान"),

    // Reasoning
    Question("Reasoning","A, C, E, G, ? पुढील अक्षर कोणते?",listOf("H","I","J","K"),1,"अक्षर मालिका"),
    Question("Reasoning","3, 9, 27, 81, ? पुढील संख्या कोणती?",listOf("162","216","243","324"),2,"संख्या मालिका"),
    Question("Reasoning","जर CAT = DBU असेल, तर DOG = ?",listOf("EPH","EOG","DPH","FPI"),0,"Coding-Decoding"),
    Question("Reasoning","एका रांगेत राहुल डावीकडून 8वा आणि उजवीकडून 13वा आहे. एकूण किती जण?",listOf("19","20","21","22"),1,"क्रमांक"),
    Question("Reasoning","5, 10, 20, 40, ? पुढील संख्या कोणती?",listOf("60","70","80","90"),2,"संख्या मालिका"),
    Question("Reasoning","जर NORTH ला OQSUJ असे कोड केले, तर EAST चे योग्य कोड कोणते?",listOf("FBTU","FZTU","DBRS","GAST"),0,"Coding-Decoding"),
    Question("Reasoning","मोहन हा सोहनपेक्षा उंच आहे आणि सोहन हा रोहनपेक्षा उंच आहे. सर्वांत ठेंगणा कोण?",listOf("मोहन","सोहन","रोहन","माहिती अपुरी"),2,"तुलना"),
    Question("Reasoning","घड्याळात 3 वाजता मिनिट काटा कोणत्या अंकावर असतो?",listOf("3","6","9","12"),3,"दिशा व घड्याळ"),

    // Mixed extra practice
    Question("मराठी","‘जलद’ या शब्दाचा समानार्थी शब्द कोणता?",listOf("वेगवान","मंद","जड","शांत"),0,"शब्दसंपदा"),
    Question("मराठी","‘नीलकमल’ हा कोणत्या समासाचा प्रकार आहे?",listOf("कर्मधारय","द्वंद्व","बहुव्रीही","अव्ययीभाव"),0,"समास"),
    Question("गणित","200 च्या 15% किती?",listOf("20","25","30","35"),2,"टक्केवारी"),
    Question("गणित","9² + 4² = ?",listOf("81","97","105","117"),1,"मूलभूत गणित"),
    Question("GK/GS","पृथ्वीचा नैसर्गिक उपग्रह कोणता?",listOf("सूर्य","चंद्र","मंगळ","शुक्र"),1,"सामान्य विज्ञान"),
    Question("GK/GS","भारताचे राष्ट्रगीत कोणी लिहिले?",listOf("रवींद्रनाथ टागोर","बंकिमचंद्र चट्टोपाध्याय","कुसुमाग्रज","विनोबा भावे"),0,"भारत GK"),
    Question("Reasoning","B, D, F, H, ? पुढील अक्षर कोणते?",listOf("I","J","K","L"),1,"अक्षर मालिका"),
    Question("Reasoning","1, 4, 9, 16, ? पुढील संख्या कोणती?",listOf("20","24","25","27"),2,"संख्या मालिका")
)

data class MockTest(val title: String, val subtitle: String, val category: String, val count: Int)

private val mockTests = listOf(
    MockTest("Marathi Grammar Mock", "व्याकरणावर timed test", "मराठी", 8),
    MockTest("Maths Mock", "गणिताचा जलद सराव", "गणित", 8),
    MockTest("GK / GS Mock", "सामान्यज्ञान + विज्ञान", "GK/GS", 8),
    MockTest("Reasoning Mock", "तर्कशक्तीचा सराव", "Reasoning", 8),
    MockTest("Full Syllabus Mock", "सर्व विषयांचा mixed test", "All", 32)
)

private val topicMocks = listOf(
    MockTest("संधी + समास", "मराठी topic practice", "TOPIC::संधी", 4),
    MockTest("शब्दसंपदा", "समानार्थी + विरुद्धार्थी", "TOPIC::शब्दसंपदा", 4),
    MockTest("टक्केवारी", "Percentage practice", "TOPIC::टक्केवारी", 4),
    MockTest("संख्या मालिका", "Number series practice", "TOPIC::संख्या मालिका", 4),
    MockTest("सामान्य विज्ञान", "Science quick test", "TOPIC::सामान्य विज्ञान", 4),
    MockTest("भारतीय राज्यघटना", "Constitution practice", "TOPIC::भारतीय राज्यघटना", 4),
    MockTest("Coding-Decoding", "Coding practice", "TOPIC::Coding-Decoding", 4),
    MockTest("क्रमांक + तुलना", "Ranking practice", "TOPIC::क्रमांक", 4)
)

private fun parseTimeSeconds(v: String): Double? {
    val t=v.trim()
    if (t.contains(":")) {
        val p=t.split(":"); if (p.size==2) return (p[0].toDoubleOrNull() ?: return null)*60+(p[1].toDoubleOrNull() ?: return null)
    }
    return t.toDoubleOrNull()
}
private fun formatTime(s: Double) = if (s >= 60) "${(s/60).toInt()}:${String.format(Locale.getDefault(),"%04.1f",s%60)}"
else String.format(Locale.getDefault(),"%.1f sec",s)

private fun dateKey(ts: Long) = SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date(ts))
private fun todayCount(ts: List<Long>) = ts.count { dateKey(it) == dateKey(System.currentTimeMillis()) }

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            LakshyaKhakiApp(
                requestNotificationPermission = {
                    if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            )
        }
    }
}



data class CommunityV27Post(
    val id: Int,
    val author: String,
    val text: String,
    val likes: Int = 0,
    val replies: Int = 0
)

@Composable
fun CommunityV27Screen(
    onBack: () -> Unit
) {
    var nextId by remember { mutableStateOf(4) }
    var newPost by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var posts by remember {
        mutableStateOf(
            listOf(
                CommunityV27Post(1, "Lakshya Khaki", "आजचा अभ्यास target पूर्ण केला! 🔥", 12, 3),
                CommunityV27Post(2, "Police Aspirant", "1600m practice आज झाली. Consistency is key.", 8, 2),
                CommunityV27Post(3, "Study Buddy", "Maths मध्ये कोणता topic आज revise करताय?", 5, 4)
            )
        )
    }

    val filtered = posts.filter {
        search.isBlank() ||
        it.author.contains(search, ignoreCase = true) ||
        it.text.contains(search, ignoreCase = true)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Community", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onBack) { Text("Back") }
        }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search posts") },
            singleLine = true
        )

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = newPost,
            onValueChange = { newPost = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Write an update") },
            minLines = 2
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val clean = newPost.trim()
                if (clean.isNotEmpty()) {
                    posts = listOf(
                        CommunityV27Post(nextId, "You", clean)
                    ) + posts
                    nextId += 1
                    newPost = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Post") }

        Spacer(Modifier.height(12.dp))
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filtered, key = { it.id }) { post ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(post.author, style = MaterialTheme.typography.titleMedium)
                            TextButton(
                                onClick = { posts = posts.filterNot { it.id == post.id } }
                            ) { Text("Delete") }
                        }
                        Text(post.text)
                        Spacer(Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(Modifier.height(4.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            TextButton(onClick = {
                                posts = posts.map {
                                    if (it.id == post.id) it.copy(likes = it.likes + 1) else it
                                }
                            }) { Text("♥ ${post.likes}") }
                            TextButton(onClick = {}) { Text("↩ ${post.replies}") }
                            TextButton(onClick = {}) { Text("Report") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CommunityPlusCard(
    onOpen: () -> Unit
) {
    var showPremium by remember { mutableStateOf(false) }
    var profileUserId by remember { mutableStateOf<String?>(null) }
    var selectedImageUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var uploadingPost by remember { mutableStateOf(false) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedImageUri = uri }
    var savedPostIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text("Community Plus", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Share preparation updates, reply to others and build your study community.")
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = onOpen) { Text("Open Community") }
            OutlinedButton(onClick = { showPremium = true }) { Text("Premium") }
        }

        if (showPremium) {
            AlertDialog(
                onDismissRequest = { showPremium = false },
                title = { Text("Premium Community") },
                text = { Text("Premium features are prepared for a future online rollout.") },
                confirmButton = {
                    TextButton(onClick = { showPremium = false }) { Text("OK") }
                }
            )
        }
    }
}

@Composable
fun LakshyaKhakiApp(requestNotificationPermission: () -> Unit) {
    val nav = rememberNavController()
    val colors = darkColorScheme(
        primary = Color(0xFF5EA7FF),
        secondary = Color(0xFF8CBFFF),
        background = Color(0xFF07111F),
        surface = Color(0xFF0D1A2B),
        surfaceVariant = Color(0xFF15253A)
    )
    MaterialTheme(colorScheme = colors) {
        DisposableEffect(Unit) {
            val auth = FirebaseAuth.getInstance()
            val listener = FirebaseAuth.AuthStateListener { user ->
                val route = nav.currentBackStackEntry?.destination?.route
                if (user == null && route !in setOf("intro", "welcome", "login", "signup")) {
                    nav.navigate("login") { popUpTo(0) }
                }
            }
            auth.addAuthStateListener(listener)
            onDispose { auth.removeAuthStateListener(listener) }
        }
        val current = nav.currentBackStackEntryAsState().value?.destination?.route
        val authRoutes = setOf("intro", "welcome", "login", "signup", "onboarding")
        Scaffold(
            containerColor = colors.background,
            bottomBar = {
                if (current !in authRoutes && current != null) {
                    NavigationBar(containerColor = Color(0xFF0A1626)) {
                        listOf("home" to "Home", "study" to "Study", "ground" to "Ground", "progress" to "Progress", "profile" to "Profile").forEach { (route, label) ->
                            NavigationBarItem(
                                selected = current == route,
                                onClick = { nav.navigate(route) { launchSingleTop = true; popUpTo("home") { saveState = true } } },
                                icon = { Text(if (route == "home") "⌂" else if (route == "study") "📚" else if (route == "ground") "🏃" else if (route == "progress") "📈" else "👤") },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(nav, "intro", Modifier.padding(padding)) {
                composable("intro") { IntroScreen(nav) }
                composable("welcome") { WelcomeScreen(nav) }
                composable("login") { AuthScreen(nav, signUp = false) }
                composable("signup") { AuthScreen(nav, signUp = true) }
                composable("onboarding") { OnboardingScreen(nav) }

                composable("home") { Home(nav) }
                composable("community") { CommunityScreen(onBack = { nav.popBackStack() }) }
                composable("daily_affairs") { DailyAffairsScreen() }
                composable("study") { Study(onQuiz = { cat -> nav.navigate("quiz/${cat.replace("/", "_")}") }, onMocks = { nav.navigate("mocks") }) }
                composable("mocks") { MockTests { cat -> nav.navigate("quiz/${cat.replace("/", "_")}") } }
                composable("quiz/{category}") { back ->
                    val cat = back.arguments?.getString("category")?.replace("_", "/") ?: "All"
                    Quiz(cat) { nav.popBackStack() }
                }
                composable("ground") { Ground() }
                composable("progress") { Progress() }
                composable("profile") { Profile(nav, requestNotificationPermission) }
                composable("admin") { AdminModerationScreen { nav.popBackStack() } }
                composable("community_profile/{uid}") { back -> CommunityProfileScreen(back.arguments?.getString("uid") ?: "", nav) }
                composable("community_search") { CommunityUserSearchScreen(nav) }
                composable("post_detail/{postId}") { back -> PostDetailScreen(nav, back.arguments?.getString("postId") ?: "") }
                composable("followers/{uid}") { back -> FollowListScreen(nav, back.arguments?.getString("uid") ?: "", false) }
                composable("following/{uid}") { back -> FollowListScreen(nav, back.arguments?.getString("uid") ?: "", true) }
                composable("user_posts/{uid}") { back -> UserPostsScreen(nav, back.arguments?.getString("uid") ?: "") }
                composable("saved_posts") { SavedPostsScreen(nav) }
                composable("daily") { DailyGoals() }
                composable("mistakes") { MistakeBook(nav) }
                composable("smart") { SmartPractice(nav) }
                composable("rank") { RankSystem(nav) }
                composable("analytics") { AnalyticsDashboard(nav) }
                composable("missions") { DailyMissions(nav) }
                composable("planner") { StudyPlanner(nav) }
                composable("reminders") { ReminderSettings(requestNotificationPermission) }
                composable("notifications") { NotificationCenter() }
            }
        }
    }
}

@Composable
private fun IntroScreen(nav: NavHostController) {
    val context = LocalContext.current
    var firstLaunch by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) {
        firstLaunch = !(context.lakshyaDataStore.data.first()[INTRO_SEEN] ?: false)
        delay(if (firstLaunch == true) 1800 else 500)
        if (firstLaunch == true) {
            nav.navigate("welcome") { popUpTo("intro") { inclusive = true } }
        } else {
            val user = FirebaseAuth.getInstance().currentUser
            if (user == null) {
                nav.navigate("login") { popUpTo("intro") { inclusive = true } }
            } else {
                FirebaseFirestore.getInstance().collection("users").document(user.uid).get()
                    .addOnSuccessListener { doc ->
                        val destination = if (doc.getBoolean("onboardingComplete") == true) "home" else "onboarding"
                        nav.navigate(destination) { popUpTo("intro") { inclusive = true } }
                    }
                    .addOnFailureListener {
                        nav.navigate("onboarding") { popUpTo("intro") { inclusive = true } }
                    }
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xFF071A33)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(112.dp).background(Color(0xFF1264E8), RoundedCornerShape(32.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("🎯", fontSize = 52.sp)
            }
            Text("लक्ष्य खाकी", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("तुमचे लक्ष्य, आमचे मार्गदर्शन.", color = Color(0xFFB8D7FF), fontSize = 16.sp)
            Text("MAHARASHTRA POLICE BHARTI", color = Color(0xFF79B3FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun WelcomeScreen(nav: NavHostController) {
    val context = LocalContext.current
    Box(Modifier.fillMaxSize().background(Color(0xFF071A33))) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(28.dp))
                Box(
                    Modifier.size(118.dp).background(Color(0xFF0E5DE8), RoundedCornerShape(36.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("🎯", fontSize = 58.sp) }
                Spacer(Modifier.height(18.dp))
                Text("लक्ष्य खाकी", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("तुमचे लक्ष्य, आमचे मार्गदर्शन.", color = Color(0xFFBBD9FF), fontSize = 16.sp)
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xE61A75F5))
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("तयारीची सुरुवात इथून करा", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Study • Mock Tests • Ground • Progress • Community", color = Color(0xFFDCEBFF))
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                                context.lakshyaDataStore.edit { it[INTRO_SEEN] = true }
                            }
                            nav.navigate("signup") { popUpTo("welcome") { inclusive = true } }
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF0757D5))
                    ) { Text("GET STARTED", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                    OutlinedButton(
                        onClick = {
                            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { context.lakshyaDataStore.edit { it[INTRO_SEEN] = true } }
                            nav.navigate("login") { popUpTo("welcome") { inclusive = true } }
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White)
                    ) { Text("I ALREADY HAVE AN ACCOUNT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                }
            }
        }
    }
}

@Composable
private fun AuthScreen(nav: NavHostController, signUp: Boolean) {
    val auth = remember { FirebaseAuth.getInstance() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }

    fun finishAuth() {
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { context.lakshyaDataStore.edit { it[INTRO_SEEN] = true } }
        val user = auth.currentUser
        if (user == null) return
        FirebaseFirestore.getInstance().collection("users").document(user.uid).get()
            .addOnSuccessListener { doc ->
                val complete = doc.getBoolean("onboardingComplete") == true
                val destination = if (complete) "home" else "onboarding"
                nav.navigate(destination) {
                    popUpTo("login") { inclusive = true }
                    popUpTo("signup") { inclusive = true }
                }
            }
            .addOnFailureListener {
                nav.navigate("onboarding") {
                    popUpTo("login") { inclusive = true }
                    popUpTo("signup") { inclusive = true }
                }
            }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF071A33)).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(76.dp).background(Color(0xFF1264E8), RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
            Text("🎯", fontSize = 38.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(if (signUp) "Create your account" else "Welcome back", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("लक्ष्य खाकी", color = Color(0xFF8DBFFF), fontSize = 15.sp)
        Spacer(Modifier.height(22.dp))

        if (signUp) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Full Name") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true)
        if (signUp) {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(confirm, { confirm = it }, Modifier.fillMaxWidth(), label = { Text("Confirm Password") }, singleLine = true)
        }

        if (!signUp) {
            TextButton(onClick = {
                if (email.trim().isBlank()) error = "आधी तुमचा email भरा."
                else auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { info = if (it.isSuccessful) "Password reset email पाठवला आहे." else (it.exception?.localizedMessage ?: "Reset failed") }
            }, Modifier.align(Alignment.End)) { Text("Forgot Password?") }
        }

        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 6.dp))
        if (info.isNotBlank()) Text(info, color = Color(0xFF8DFFB2), modifier = Modifier.padding(vertical = 6.dp))

        Button(
            enabled = !loading,
            onClick = {
                val e = email.trim()
                when {
                    e.isBlank() || !e.contains("@") -> error = "Valid email भरा."
                    password.length < 6 -> error = "Password किमान 6 characters असावा."
                    signUp && name.trim().isBlank() -> error = "तुमचे नाव भरा."
                    signUp && password != confirm -> error = "Passwords match होत नाहीत."
                    else -> {
                        loading = true; error = ""
                        val task = if (signUp) auth.createUserWithEmailAndPassword(e, password) else auth.signInWithEmailAndPassword(e, password)
                        task.addOnCompleteListener { result ->
                            loading = false
                            if (result.isSuccessful) {
                                val user = auth.currentUser
                                if (signUp && user != null) {
                                    FirebaseFirestore.getInstance().collection("users").document(user.uid).set(
                                        mapOf("name" to name.trim(), "email" to e, "createdAt" to FieldValue.serverTimestamp()),
                                        com.google.firebase.firestore.SetOptions.merge()
                                    )
                                }
                                finishAuth()
                            } else error = result.exception?.localizedMessage ?: "Authentication failed."
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(18.dp)
        ) { Text(if (loading) "Please wait…" else if (signUp) "CREATE ACCOUNT" else "SIGN IN", fontWeight = FontWeight.Bold) }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            HorizontalDivider(Modifier.weight(1f)); Text("  OR  ", color = Color(0xFF91A7C2)); HorizontalDivider(Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            enabled = !loading,
            onClick = {
                loading = true
                error = ""
                info = ""
                scope.launch {
                    try {
                        val googleIdOption = GetGoogleIdOption.Builder()
                            .setServerClientId(context.getString(com.lakshyakhaki.app.R.string.default_web_client_id))
                            .setFilterByAuthorizedAccounts(false)
                            .build()
                        val request = GetCredentialRequest.Builder()
                            .addCredentialOption(googleIdOption)
                            .build()
                        val result = credentialManager.getCredential(context, request)
                        val credential = result.credential
                        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                            val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data)
                            val firebaseCredential = com.google.firebase.auth.GoogleAuthProvider.getCredential(googleIdToken.idToken, null)
                            val authResult = auth.signInWithCredential(firebaseCredential).await()
                            val user = authResult.user
                            if (user != null) {
                                FirebaseFirestore.getInstance().collection("users").document(user.uid).set(
                                    mapOf(
                                        "name" to (user.displayName ?: ""),
                                        "email" to (user.email ?: ""),
                                        "photoUrl" to (user.photoUrl?.toString() ?: ""),
                                        "lastLoginAt" to FieldValue.serverTimestamp()
                                    ),
                                    com.google.firebase.firestore.SetOptions.merge()
                                ).await()
                            }
                            loading = false
                            finishAuth()
                        } else {
                            loading = false
                            error = "Google credential मिळाले नाही."
                        }
                    } catch (e: GoogleIdTokenParsingException) {
                        loading = false
                        error = "Google sign-in data process करता आले नाही."
                    } catch (e: Exception) {
                        loading = false
                        error = e.localizedMessage ?: "Google Sign-In failed."
                    }
                }
            },
            Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (loading) "Please wait…" else "🌈  Continue with Google", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(4.dp))
        TextButton(onClick = { nav.navigate(if (signUp) "login" else "signup") }) {
            Text(if (signUp) "Already have an account? Sign In" else "Create New Account")
        }
        TextButton(onClick = { nav.popBackStack() }) { Text("← Back") }
    }

}


@Composable
private fun OnboardingScreen(nav: NavHostController) {
    val context = LocalContext.current
    val user = FirebaseAuth.getInstance().currentUser
    val firestore = FirebaseFirestore.getInstance()
    var name by remember { mutableStateOf(user?.displayName ?: "") }
    var district by remember { mutableStateOf("") }
    var recruitment by remember { mutableStateOf("Maharashtra Police") }
    var targetYear by remember { mutableStateOf("2026") }
    var goal by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var showDistricts by remember { mutableStateOf(false) }
    var showYears by remember { mutableStateOf(false) }

    val districts = listOf("Pune", "Satara", "Mumbai", "Nashik", "Kolhapur", "Sangli", "Nagpur", "Aurangabad", "Other")
    val years = listOf("2026", "2027", "2028", "2029")

    fun finish() {
        if (user == null) { nav.navigate("login") { popUpTo(0) }; return }
        if (name.trim().isBlank() || district.isBlank() || goal.isBlank()) {
            error = "कृपया नाव, जिल्हा आणि तुमचे goal निवडा."
            return
        }
        loading = true; error = ""
        val data = mapOf(
            "name" to name.trim(),
            "email" to (user.email ?: ""),
            "district" to district,
            "targetRecruitment" to recruitment,
            "targetYear" to targetYear,
            "goal" to goal,
            "onboardingComplete" to true,
            "onboardingUpdatedAt" to FieldValue.serverTimestamp()
        )
        firestore.collection("users").document(user.uid).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener {
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    context.lakshyaDataStore.edit { it[ONBOARDING_COMPLETE] = true }
                }
                loading = false
                nav.navigate("home") { popUpTo("onboarding") { inclusive = true } }
            }
            .addOnFailureListener { loading = false; error = it.localizedMessage ?: "Profile save failed." }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF071A33)).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("चला, तुमची तयारी सेट करूया 🎯", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("ही माहिती तुमच्या study plan आणि progress साठी वापरली जाईल.", color = Color(0xFFBBD9FF))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("तुमचे नाव") }, singleLine = true)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton({ showDistricts = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text(if (district.isBlank()) "जिल्हा निवडा" else "जिल्हा: $district") }
        }
        OutlinedButton({ showYears = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Target Year: $targetYear") }
        Text("तुमची Target Recruitment", color = Color.White, fontWeight = FontWeight.Bold)
        listOf("Maharashtra Police", "Pune City", "Pune Gramin", "Pimpri-Chinchwad").forEach { item ->
            FilterChip(selected = recruitment == item, onClick = { recruitment = item }, label = { Text(item) }, modifier = Modifier.fillMaxWidth())
        }
        Text("तुमचे मुख्य Goal", color = Color.White, fontWeight = FontWeight.Bold)
        listOf("Written Exam मध्ये 80+", "Ground मध्ये Full Marks", "Written + Ground दोन्ही Strong").forEach { item ->
            FilterChip(selected = goal == item, onClick = { goal = item }, label = { Text(item) }, modifier = Modifier.fillMaxWidth())
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.weight(1f))
        Button({ finish() }, enabled = !loading, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
            Text(if (loading) "Saving…" else "LET'S START", fontWeight = FontWeight.Bold)
        }
    }

    if (showDistricts) AlertDialog(
        onDismissRequest = { showDistricts = false },
        title = { Text("तुमचा जिल्हा") },
        text = { Column { districts.forEach { d -> TextButton({ district = d; showDistricts = false }, Modifier.fillMaxWidth()) { Text(d) } } } },
        confirmButton = { TextButton({ showDistricts = false }) { Text("Cancel") } }
    )
    if (showYears) AlertDialog(
        onDismissRequest = { showYears = false },
        title = { Text("Target Year") },
        text = { Column { years.forEach { y -> TextButton({ targetYear = y; showYears = false }, Modifier.fillMaxWidth()) { Text(y) } } } },
        confirmButton = { TextButton({ showYears = false }) { Text("Cancel") } }
    )
}

@Composable
fun Home(nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var todayQuiz by remember { mutableStateOf(0) }
    var todayGround by remember { mutableStateOf(0) }
    var xp by remember { mutableStateOf(0) }
    var profileName by remember { mutableStateOf("") }
    var profileDistrict by remember { mutableStateOf("") }
    var profileRecruitment by remember { mutableStateOf("Maharashtra Police") }
    var profileTargetYear by remember { mutableStateOf("2026") }
    var profileGoal by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        todayQuiz = db.quizDao().all().first()
            .count { System.currentTimeMillis() - it.timestamp < 24L * 60 * 60 * 1000 }
        todayGround = db.groundDao().all().first()
            .count { System.currentTimeMillis() - it.timestamp < 24L * 60 * 60 * 1000 }
        xp = context.lakshyaDataStore.data.first()[LEADERBOARD_POINTS] ?: 0

        FirebaseAuth.getInstance().currentUser?.let { user ->
            FirebaseFirestore.getInstance().collection("users").document(user.uid).get()
                .addOnSuccessListener { doc ->
                    profileName = doc.getString("name")?.takeIf { it.isNotBlank() }
                        ?: user.displayName?.takeIf { it.isNotBlank() }
                        ?: user.email?.substringBefore("@")?.replaceFirstChar { it.uppercase() }
                        ?: "Candidate"
                    profileDistrict = doc.getString("district") ?: ""
                    profileRecruitment = doc.getString("targetRecruitment") ?: "Maharashtra Police"
                    profileTargetYear = doc.getString("targetYear") ?: "2026"
                    profileGoal = doc.getString("goal") ?: ""
                }
        }
    }

    val displayName = profileName.ifBlank { "Candidate" }
    val targetLine = listOf(profileDistrict, profileTargetYear).filter { it.isNotBlank() }.joinToString(" • ")

    val todayProgress = ((todayQuiz * 10 + todayGround * 15) / 50f).coerceIn(0f, 1f)

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    Modifier.padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("लक्ष्य खाकी", style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold)
                    Text("तुमचे लक्ष्य, आमचे मार्गदर्शन.",
                        style = MaterialTheme.typography.titleMedium)
                    Text("आजची तयारी सुरू ठेवा 💪",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2850))
            ) {
                Column(
                    Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("नमस्कार, $displayName 👋", color = Color.White,
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("तुमची Police Bharti तयारी आजपासून तुमच्या goal नुसार.",
                        color = Color(0xFFBBD9FF))
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { }, label = { Text(profileRecruitment) })
                        if (targetLine.isNotBlank()) {
                            AssistChip(onClick = { }, label = { Text(targetLine) })
                        }
                    }
                    if (profileGoal.isNotBlank()) {
                        Text("🎯 Goal: $profileGoal", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                    Text("Profile बदलण्यासाठी Profile → Edit Profile वापरा.",
                        color = Color(0xFF8DBFFF), style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("🔥 आजची Progress", fontWeight = FontWeight.Bold)
                        Text("${(todayProgress * 100).toInt()}%")
                    }
                    LinearProgressIndicator(
                        progress = { todayProgress },
                        Modifier.fillMaxWidth()
                    )
                    Text("$todayQuiz quiz • $todayGround ground attempts • $xp XP total",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("📝 Quiz")
                        Text("$todayQuiz", style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold)
                        Text("आज")
                    }
                }
                Card(Modifier.weight(1f), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("🏃 Ground")
                        Text("$todayGround", style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold)
                        Text("आज")
                    }
                }
            }
        }

        
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🎯 आजचा Focus", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    val focusText = when {
                        profileGoal.contains("1600", ignoreCase = true) || profileGoal.contains("Ground", ignoreCase = true) -> "Ground practice करा आणि तुमचा best record track करा."
                        profileGoal.contains("written", ignoreCase = true) || profileGoal.contains("Study", ignoreCase = true) -> "आज 20 MCQs + एक topic revision पूर्ण करा."
                        else -> "20 MCQs + Ground practice + 15 मिनिटे revision — consistency ठेवूया."
                    }
                    Text(focusText, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = {
                        if (profileGoal.contains("Ground", ignoreCase = true) || profileGoal.contains("1600", ignoreCase = true)) nav.navigate("ground")
                        else nav.navigate("study")
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (profileGoal.contains("Ground", ignoreCase = true) || profileGoal.contains("1600", ignoreCase = true)) "🏃 Start Ground" else "📚 Start Study")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { nav.navigate("community") }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("👥", fontSize = 28.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Lakshya Khaki Community", fontWeight = FontWeight.Bold)
                        Text("Post करा • Reply करा • तयारीची चर्चा करा", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("→", fontSize = 22.sp)
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clickable { nav.navigate("notifications") }
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔔", fontSize = 28.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Notifications", fontWeight = FontWeight.Bold)
                        Text("App reminders आणि community updates", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("→", fontSize = 22.sp)
                }
            }

            DailyAffairsCard(onOpenAll = { nav.navigate("daily_affairs") })
        }

item {
            Text("⚡ Quick Actions", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold)
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ nav.navigate("mocks") }, Modifier.weight(1f)) {
                    Text("🎯 Mock Test")
                }
                Button({ nav.navigate("missions") }, Modifier.weight(1f)) {
                    Text("🔥 Missions")
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton({ nav.navigate("planner") }, Modifier.fillMaxWidth()) {
                    Text("📅 Study Planner")
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton({ nav.navigate("analytics") }, Modifier.weight(1f)) {
                    Text("📊 Analytics")
                }
                OutlinedButton({ nav.navigate("rank") }, Modifier.weight(1f)) {
                    Text("🏆 Rank")
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("💡 आजचा Focus", fontWeight = FontWeight.Bold)
                    Text("एक mock test + एक ground attempt पूर्ण करण्याचा प्रयत्न करा.")
                }
            }
        }
    }
}


@Composable
fun DailyAffairsCard(onOpenAll: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<DailyAffair>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            loading = true
            error = false
            val result = withContext(Dispatchers.IO) { fetchDailyAffairs() }
            items = result.take(4)
            error = result.isEmpty()
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("📰 Live Daily Affairs", style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold)
                    Text("आजच्या चालू घडामोडी",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall)
                }
                TextButton({ refresh() }) { Text("↻") }
            }

            OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            label = { Text("Search community") },
            singleLine = true
        )

        val visiblePosts = posts.filter {
            search.isBlank() ||
                it.authorName.contains(search, ignoreCase = true) ||
                it.text.contains(search, ignoreCase = true)
        }

        if (loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("Daily Affairs loading...")
            } else if (error) {
                Text("Internet connection तपासा आणि Refresh करा.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                items.forEach { item ->
                    Column(
                        Modifier.fillMaxWidth()
                            .clickable { openNews(context, item.link) }
                            .padding(vertical = 3.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(item.title, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${item.source.ifBlank { "News source" }} • ${item.published.take(16)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                OutlinedButton(onOpenAll, Modifier.fillMaxWidth()) {
                    Text("सर्व Daily Affairs पाहा →")
                }
            }
        }
    }
}


@Composable
fun NotificationCenter() {
    val context = LocalContext.current
    var reminderEnabled by remember { mutableStateOf(false) }
    var reminderHour by remember { mutableStateOf(19) }
    var reminderMinute by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        val prefs = context.lakshyaDataStore.data.first()
        reminderEnabled = prefs[REMINDER_ENABLED] ?: false
        reminderHour = prefs[REMINDER_HOUR] ?: 19
        reminderMinute = prefs[REMINDER_MINUTE] ?: 0
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("🔔 Notifications", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("तुमच्या अभ्यासासाठी reminders आणि future community alerts इथे manage करा.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Daily Study Reminder", fontWeight = FontWeight.Bold)
                        Text(String.format(Locale.getDefault(), "%02d:%02d", reminderHour, reminderMinute))
                    }
                    Switch(
                        checked = reminderEnabled,
                        onCheckedChange = { enabled ->
                            reminderEnabled = enabled
                            if (enabled) scheduleDailyReminder(context, reminderHour, reminderMinute)
                            else cancelDailyReminder(context)
                            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                                context.lakshyaDataStore.edit {
                                    it[REMINDER_ENABLED] = enabled
                                    it[REMINDER_HOUR] = reminderHour
                                    it[REMINDER_MINUTE] = reminderMinute
                                }
                            }
                        }
                    )
                }
                Button(onClick = {
                    TimePickerDialog(context, { _, h, m ->
                        reminderHour = h; reminderMinute = m
                        if (reminderEnabled) scheduleDailyReminder(context, h, m)
                        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                            context.lakshyaDataStore.edit {
                                it[REMINDER_ENABLED] = reminderEnabled
                                it[REMINDER_HOUR] = h
                                it[REMINDER_MINUTE] = m
                            }
                        }
                    }, reminderHour, reminderMinute, true).show()
                }, Modifier.fillMaxWidth()) { Text("Change reminder time") }
            }
        }

        CommunityNotificationList()

        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🌐 Community Notifications", fontWeight = FontWeight.Bold)
                Text("Firebase Cloud Messaging (FCM) support is prepared in V32. Push alerts can be connected later using Firebase Console / Cloud Functions.")
            }
        }
    }
}


@Composable
private fun CommunityNotificationList() {
    val user = FirebaseAuth.getInstance().currentUser ?: return
    val firestore = remember { FirebaseFirestore.getInstance() }
    var items by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    DisposableEffect(user.uid) {
        val reg = firestore.collection("users").document(user.uid).collection("notifications")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(30)
            .addSnapshotListener { snap, _ ->
                items = snap?.documents?.map { (it.getString("message") ?: "Community update") to it.id } ?: emptyList()
            }
        onDispose { reg.remove() }
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("👥 Community Alerts", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (items.isEmpty()) Text("अजून community notifications नाहीत.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            items.take(8).forEach { (message, id) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("• $message", Modifier.weight(1f))
                    TextButton(onClick = { firestore.collection("users").document(user.uid).collection("notifications").document(id).update("read", true) }) { Text("Read") }
                }
            }
        }
    }
}

@Composable
fun CommunityScreen(onBack: () -> Unit) {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var showAuth by remember { mutableStateOf(user == null) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { user = it; showAuth = it == null }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    if (user == null || showAuth) {
        FirebaseLoginScreen(
            auth = auth,
            onSuccess = { showAuth = false }
        )
        return
    }

    FirebaseCommunityFeed(
        auth = auth,
        onBack = onBack
    )
}

@Composable
private fun FirebaseLoginScreen(
    auth: FirebaseAuth,
    onSuccess: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var signUp by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("👥 Lakshya Khaki Community", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(if (signUp) "नवीन account तयार करा" else "Community मध्ये login करा")
        Spacer(Modifier.height(20.dp))

        if (signUp) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("तुमचे नाव") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true)
        Spacer(Modifier.height(14.dp))

        if (error.isNotBlank()) {
            Text(error, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
        }

        Button(
            enabled = !loading,
            onClick = {
                val cleanEmail = email.trim()
                if (cleanEmail.isBlank() || password.length < 6 || (signUp && name.trim().isBlank())) {
                    error = "Email भरा आणि password किमान 6 characters ठेवा."
                    return@Button
                }
                loading = true
                error = ""
                val task = if (signUp) auth.createUserWithEmailAndPassword(cleanEmail, password)
                else auth.signInWithEmailAndPassword(cleanEmail, password)
                task.addOnCompleteListener { result ->
                    loading = false
                    if (result.isSuccessful) {
                        val current = auth.currentUser
                        if (signUp && current != null) {
                            val profile = hashMapOf<String, Any>(
                                "name" to name.trim(),
                                "email" to cleanEmail,
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                            FirebaseFirestore.getInstance().collection("users").document(current.uid).set(profile)
                        }
                        onSuccess()
                    } else {
                        error = result.exception?.localizedMessage ?: "Login failed."
                    }
                }
            }
        ) { Text(if (loading) "Please wait..." else if (signUp) "Create Account" else "Login") }

        TextButton(onClick = { signUp = !signUp; error = "" }) {
            Text(if (signUp) "Already have an account? Login" else "New user? Create account")
        }
    }
}

data class CommunityReport(
    val postId: String = "",
    val reporterId: String = "",
    val reason: String = "",
    val createdAt: Any? = null
)

private const val ADMIN_UID = "PUT_YOUR_ADMIN_FIREBASE_UID_HERE"

private fun userDisplayName(user: com.google.firebase.auth.FirebaseUser?): String =
    user?.displayName?.takeIf { it.isNotBlank() }
        ?: user?.email?.substringBefore("@")
        ?: "User"

data class CloudinaryUploadResponse(
    val secure_url: String? = null,
    val public_id: String? = null,
    val resource_type: String? = null,
    val format: String? = null,
    val bytes: Long? = null
)

data class CloudinaryDeleteResponse(
    val result: String? = null,
    val message: String? = null
)

private interface CloudinaryApi {
    @Multipart
    @POST
    suspend fun uploadImage(
        @Url endpoint: String,
        @Part file: MultipartBody.Part,
        @Part("upload_preset") uploadPreset: okhttp3.RequestBody
    ): CloudinaryUploadResponse
}

private interface MediaDeleteApi {
    @POST
    suspend fun deleteMedia(
        @Url endpoint: String,
        @retrofit2.http.Query("public_id") publicId: String,
        @retrofit2.http.Query("resource_type") resourceType: String = "image"
    ): CloudinaryDeleteResponse
}

private object CloudinaryNetwork {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.cloudinary.com/")
        .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
        .build()

    val api: CloudinaryApi = retrofit.create(CloudinaryApi::class.java)
    val deleteApi: MediaDeleteApi = retrofit.create(MediaDeleteApi::class.java)
}

private suspend fun uploadImageToCloudinary(
    context: Context,
    uri: android.net.Uri
): CloudinaryUploadResponse = withContext(Dispatchers.IO) {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: throw IllegalStateException("Image open failed")
    val fileBody = bytes.toRequestBody("application/octet-stream".toMediaType())
    val filePart = MultipartBody.Part.createFormData(
        "file",
        "lakshya_${System.currentTimeMillis()}",
        fileBody
    )
    val preset = BuildConfig.CLOUDINARY_UPLOAD_PRESET.toRequestBody("text/plain".toMediaType())
    val endpoint = "v1_1/${BuildConfig.CLOUDINARY_CLOUD_NAME}/image/upload"
    CloudinaryNetwork.api.uploadImage(endpoint, filePart, preset)
}

private suspend fun deleteCloudinaryImage(publicId: String): CloudinaryDeleteResponse =
    withContext(Dispatchers.IO) {
        if (BuildConfig.DELETE_BACKEND_URL.contains("YOUR-BACKEND-DOMAIN")) {
            throw IllegalStateException("DELETE_BACKEND_URL configure करा")
        }
        CloudinaryNetwork.deleteApi.deleteMedia(
            BuildConfig.DELETE_BACKEND_URL,
            publicId,
            "image"
        )
    }

private fun saveCloudinaryMediaToRealtimeDb(
    postId: String,
    uid: String,
    secureUrl: String,
    publicId: String,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    val data = mapOf(
        "postId" to postId,
        "uid" to uid,
        "secure_url" to secureUrl,
        "public_id" to publicId,
        "resource_type" to "image",
        "createdAt" to System.currentTimeMillis()
    )
    FirebaseDatabase.getInstance().reference
        .child("postMedia")
        .child(postId)
        .setValue(data)
        .addOnSuccessListener { onSuccess() }
        .addOnFailureListener { onError(it.localizedMessage ?: "Realtime Database save failed") }
}

private data class OnlineCommunityPost(
    val id: String,
    val authorId: String,
    val authorName: String,
    val text: String,
    val likes: Int,
    val likedBy: List<String>,
    val replies: Int,
    val createdAt: Long,
    val imageUrl: String = "",
    val videoUrl: String = "",
    val imagePublicId: String = ""
)

private fun postFromSnapshot(doc: com.google.firebase.firestore.DocumentSnapshot): OnlineCommunityPost {
    val likedBy = (doc.get("likedBy") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
    val timestamp = doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L
    return OnlineCommunityPost(
        id = doc.id,
        authorId = doc.getString("authorId") ?: "",
        authorName = doc.getString("authorName") ?: "User",
        text = doc.getString("text") ?: "",
        likes = (doc.getLong("likes") ?: 0L).toInt(),
        likedBy = likedBy,
        replies = (doc.getLong("replies") ?: 0L).toInt(),
        createdAt = timestamp,
        imageUrl = doc.getString("imageUrl") ?: "",
        videoUrl = doc.getString("videoUrl") ?: "",
        imagePublicId = doc.getString("imagePublicId") ?: ""
    )
}

@Composable
private fun FirebaseCommunityFeed(auth: FirebaseAuth, onBack: () -> Unit) {
    val firestore = remember { FirebaseFirestore.getInstance() }
    val current = auth.currentUser
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<OnlineCommunityPost>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var selectedReplyPost by remember { mutableStateOf<OnlineCommunityPost?>(null) }
    var reportPost by remember { mutableStateOf<OnlineCommunityPost?>(null) }
    var showPremium by remember { mutableStateOf(false) }
    var profileUserId by remember { mutableStateOf<String?>(null) }
    var selectedImageUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var uploadingPost by remember { mutableStateOf(false) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedImageUri = uri
    }

    DisposableEffect(Unit) {
        val registration = firestore.collection("posts")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    error = "Feed load झाला नाही: ${exception.localizedMessage ?: "permission/error"}"
                    loading = false
                    return@addSnapshotListener
                }
                posts = snapshot?.documents?.map(::postFromSnapshot) ?: emptyList()
                loading = false
            }
        onDispose { registration.remove() }
    }

    DisposableEffect(current?.uid) {
        if (current == null) return@DisposableEffect onDispose { }
        val registration = firestore.collection("users").document(current.uid)
            .collection("savedPosts")
            .addSnapshotListener { snap, _ ->
                savedPostIds = snap?.documents?.map { it.id }?.toSet() ?: emptySet()
            }
        onDispose { registration.remove() }
    }

    fun createPost() {
        val clean = draft.trim()
        if (clean.isBlank() || current == null || uploadingPost) return
        uploadingPost = true
        val imageUri = selectedImageUri

        fun savePost(imageUrl: String, imagePublicId: String) {
            val data = hashMapOf<String, Any>(
                "authorId" to current.uid,
                "authorName" to (current.displayName?.takeIf { it.isNotBlank() } ?: current.email?.substringBefore("@") ?: "User"),
                "text" to clean,
                "imageUrl" to imageUrl,
                "imagePublicId" to imagePublicId,
                "videoUrl" to "",
                "likes" to 0L,
                "likedBy" to emptyList<String>(),
                "replies" to 0L,
                "createdAt" to FieldValue.serverTimestamp()
            )
            firestore.collection("posts").add(data)
                .addOnSuccessListener { doc ->
                    if (imageUrl.isNotBlank() && imagePublicId.isNotBlank()) {
                        saveCloudinaryMediaToRealtimeDb(
                            doc.id, current.uid, imageUrl, imagePublicId,
                            onSuccess = {
                                draft = ""; selectedImageUri = null; uploadingPost = false
                            },
                            onError = {
                                error = it
                                uploadingPost = false
                            }
                        )
                    } else {
                        draft = ""; selectedImageUri = null; uploadingPost = false
                    }
                }
                .addOnFailureListener { error = it.localizedMessage ?: "Post failed"; uploadingPost = false }
        }

        if (imageUri != null) {
            scope.launch {
                try {
                    val result = uploadImageToCloudinary(context, imageUri)
                    val secureUrl = result.secure_url.orEmpty()
                    val publicId = result.public_id.orEmpty()
                    if (secureUrl.isBlank() || publicId.isBlank()) throw IllegalStateException("Cloudinary response incomplete")
                    withContext(Dispatchers.Main) { savePost(secureUrl, publicId) }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        error = e.localizedMessage ?: "Cloudinary upload failed"
                        uploadingPost = false
                    }
                }
            }
        } else {
            savePost("", "")
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Community", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { auth.signOut() }) { Text("Logout") }
        }

        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("🌐 Live Community", fontWeight = FontWeight.Bold)
                Text("तुमचे preparation updates share करा. Feed realtime update होईल.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { if (it.length <= 500) draft = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Post लिहा...") },
                        singleLine = false,
                        maxLines = 3
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { imagePicker.launch("image/*") }, enabled = !uploadingPost) { Text(if (selectedImageUri == null) "📷" else "✓") }
                    Spacer(Modifier.width(6.dp))
                    Spacer(Modifier.width(6.dp))
                    Button(onClick = { createPost() }, enabled = draft.isNotBlank() && !uploadingPost) { Text(if (uploadingPost) "..." else "Post") }
                }
                selectedImageUri?.let { uri ->
                    Spacer(Modifier.height(8.dp))
                    AsyncImage(model = uri, contentDescription = "Selected image", modifier = Modifier.fillMaxWidth().height(150.dp))
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Latest Posts", fontWeight = FontWeight.Bold)
            TextButton(onClick = { showPremium = true }) { Text("⭐ Premium") }
        }

        if (loading) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (visiblePosts.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text(if (posts.isEmpty()) "पहिला post तुम्ही करा 🚀" else "No matching posts found.") }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(visiblePosts, key = { it.id }) { post ->
                    OnlinePostCard(
                        post = post,
                        currentUserId = current?.uid,
                        firestore = firestore,
                        onReply = { selectedReplyPost = post },
                        onOpenDetail = { nav.navigate("post_detail/${post.id}") },
                        onReport = { reportPost = post },
                        onProfile = { uid -> profileUserId = uid },
                        saved = savedPostIds.contains(post.id),
                        onError = { error = it }
                    )
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
    }

    if (selectedReplyPost != null) {
        ReplyDialog(
            post = selectedReplyPost!!,
            firestore = firestore,
            currentUser = current,
            onDismiss = { selectedReplyPost = null },
            onError = { error = it }
        )
    }

    if (reportPost != null) {
        ReportDialog(
            post = reportPost!!, firestore = firestore, currentUser = current,
            onDismiss = { reportPost = null }, onError = { error = it }
        )
    }

    if (profileUserId != null) {
        CommunityProfileScreen(uid = profileUserId!!, nav = null, onDismiss = { profileUserId = null })
    }

    if (showPremium) {
        AlertDialog(
            onDismissRequest = { showPremium = false },
            title = { Text("⭐ Premium Community") },
            text = { Text("Premium-ready: future मध्ये exclusive discussions आणि advanced study features add करता येतील.") },
            confirmButton = { TextButton(onClick = { showPremium = false }) { Text("OK") } }
        )
    }
}

@Composable
private fun OnlinePostCard(
    post: OnlineCommunityPost,
    currentUserId: String?,
    firestore: FirebaseFirestore,
    onReply: () -> Unit,
    onOpenDetail: () -> Unit,
    onReport: () -> Unit,
    onProfile: (String) -> Unit,
    saved: Boolean,
    onError: (String) -> Unit
) {
    val liked = currentUserId != null && post.likedBy.contains(currentUserId)
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(post.authorName, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onProfile(post.authorId) })
                Spacer(Modifier.weight(1f))
                if (post.authorId == currentUserId) {
                    IconButton(onClick = {
                        if (post.imagePublicId.isBlank()) {
                            firestore.collection("posts").document(post.id).delete()
                                .addOnSuccessListener { FirebaseDatabase.getInstance().reference.child("postMedia").child(post.id).removeValue() }
                                .addOnFailureListener { onError(it.localizedMessage ?: "Delete failed") }
                        } else {
                            onError("Image cleanup सुरू आहे...")
                            kotlinx.coroutines.CoroutineScope(Dispatchers.Main).launch {
                                try {
                                    deleteCloudinaryImage(post.imagePublicId)
                                    firestore.collection("posts").document(post.id).delete().await()
                                    FirebaseDatabase.getInstance().reference.child("postMedia").child(post.id).removeValue()
                                        .addOnFailureListener { onError(it.localizedMessage ?: "Media metadata delete failed") }
                                } catch (e: Exception) {
                                    onError(e.localizedMessage ?: "Cloudinary delete failed")
                                }
                            }
                        }
                    }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                } else {
                    IconButton(onClick = onReport) { Icon(Icons.Default.Flag, contentDescription = "Report") }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(post.text)
            if (post.imageUrl.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                AsyncImage(model = post.imageUrl, contentDescription = "Post image", modifier = Modifier.fillMaxWidth().height(220.dp))
            }
            if (post.videoUrl.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                CommunityVideoPlayer(post.videoUrl, Modifier.fillMaxWidth().height(230.dp))
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    if (currentUserId == null) return@TextButton
                    val ref = firestore.collection("posts").document(post.id)
                    firestore.runTransaction { transaction ->
                        val snap = transaction.get(ref)
                        val existing = (snap.get("likedBy") as? List<*>)?.filterIsInstance<String>()?.toMutableList() ?: mutableListOf()
                        if (existing.contains(currentUserId)) {
                            existing.remove(currentUserId)
                        } else {
                            existing.add(currentUserId)
                        }
                        transaction.update(ref, mapOf("likedBy" to existing, "likes" to existing.size.toLong()))
                    }.addOnSuccessListener {
                        if (!liked && post.authorId.isNotBlank() && post.authorId != currentUserId) {
                            createCommunityNotification(firestore, post.authorId, currentUserId ?: "", "like", "${userDisplayName(FirebaseAuth.getInstance().currentUser)} liked your post", post.id)
                        }
                    }.addOnFailureListener { onError(it.localizedMessage ?: "Like failed") }
                }) { Text(if (liked) "❤️ ${post.likes}" else "♡ ${post.likes}") }
                TextButton(onClick = onReply) { Text("💬 ${post.replies}") }
                TextButton(onClick = onOpenDetail) { Text("Open") }
                if (currentUserId != null) {
                    TextButton(onClick = {
                        val ref = firestore.collection("users").document(currentUserId)
                            .collection("savedPosts").document(post.id)
                        if (saved) {
                            ref.delete().addOnFailureListener { onError(it.localizedMessage ?: "Unsave failed") }
                        } else {
                            val data = hashMapOf<String, Any>(
                                "postId" to post.id,
                                "authorId" to post.authorId,
                                "authorName" to post.authorName,
                                "text" to post.text,
                                "imageUrl" to post.imageUrl,
                                "imagePublicId" to post.imagePublicId,
                                "videoUrl" to post.videoUrl,
                                "savedAt" to FieldValue.serverTimestamp()
                            )
                            ref.set(data).addOnFailureListener { onError(it.localizedMessage ?: "Save failed") }
                        }
                    }) { Text(if (saved) "🔖 Saved" else "🔖 Save") }
                }
                if (post.authorId != currentUserId && currentUserId != null) {
                    FollowButton(targetUid = post.authorId, targetName = post.authorName, currentUid = currentUserId, firestore = firestore, onError = onError)
                }
            }
        }
    }
}


@Composable
private fun CommunityVideoPlayer(url: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            VideoView(context).apply {
                setMediaController(MediaController(context).also { it.setAnchorView(this) })
                setVideoPath(url)
                setOnPreparedListener { mp -> mp.isLooping = false }
            }
        },
        update = { it.setVideoPath(url) }
    )
}

@Composable
private fun PostDetailScreen(nav: NavHostController, postId: String) {
    val firestore = remember { FirebaseFirestore.getInstance() }
    val context = LocalContext.current
    val current = FirebaseAuth.getInstance().currentUser
    var post by remember { mutableStateOf<OnlineCommunityPost?>(null) }
    var replies by remember { mutableStateOf<List<ReplyItem>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<ReplyItem?>(null) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(postId) {
        val reg = firestore.collection("posts").document(postId).addSnapshotListener { snap, e ->
            if (e != null) error = e.localizedMessage ?: "Post load failed"
            else post = snap?.takeIf { it.exists() }?.let(::postFromSnapshot)
        }
        onDispose { reg.remove() }
    }
    DisposableEffect(postId) {
        val reg = firestore.collection("posts").document(postId).collection("replies")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.ASCENDING)
            .addSnapshotListener { snap, e ->
                if (e != null) error = e.localizedMessage ?: "Replies load failed"
                else replies = snap?.documents?.map { d ->
                    ReplyItem(
                        id = d.id,
                        authorId = d.getString("authorId") ?: "",
                        authorName = d.getString("authorName") ?: "User",
                        text = d.getString("text") ?: "",
                        parentId = d.getString("parentId") ?: ""
                    )
                } ?: emptyList()
            }
        onDispose { reg.remove() }
    }

    fun sharePost(p: OnlineCommunityPost) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "${p.authorName}: ${p.text}\n\nLakshya Khaki Community")
        }
        context.startActivity(Intent.createChooser(send, "Share post"))
    }

    val rootReplies = replies.filter { it.parentId.isBlank() }
    val children = replies.groupBy { it.parentId }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Post Details", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        if (post == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else {
            val p = post!!
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(p.authorName, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(p.text, style = MaterialTheme.typography.bodyLarge)
                    if (p.imageUrl.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        AsyncImage(model = p.imageUrl, contentDescription = "Post image", modifier = Modifier.fillMaxWidth().height(240.dp))
                    }
                    if (p.videoUrl.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        CommunityVideoPlayer(p.videoUrl, Modifier.fillMaxWidth().height(260.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("❤️ ${p.likes}")
                        Text("💬 ${p.replies}")
                        TextButton(onClick = { sharePost(p) }) { Text("Share") }
                        TextButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Lakshya Khaki post", p.text))
                        }) { Text("Copy") }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Replies", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(rootReplies, key = { it.id }) { item ->
                    ReplyThreadItem(item, children, onReply = { replyTo = item })
                }
            }
            if (replyTo != null) {
                Text("Replying to ${replyTo!!.authorName}", style = MaterialTheme.typography.labelMedium)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { if (it.length <= 300) draft = it },
                    modifier = Modifier.weight(1f),
                    label = { Text(if (replyTo == null) "Write a reply" else "Write a threaded reply") },
                    maxLines = 3
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val user = current ?: return@Button
                    val clean = draft.trim()
                    if (clean.isBlank()) return@Button
                    val name = user.displayName?.takeIf { it.isNotBlank() } ?: user.email?.substringBefore("@") ?: "User"
                    val data = hashMapOf<String, Any>(
                        "authorId" to user.uid,
                        "authorName" to name,
                        "text" to clean,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "parentId" to (replyTo?.id ?: "")
                    )
                    firestore.collection("posts").document(postId).collection("replies").add(data)
                        .addOnSuccessListener {
                            firestore.collection("posts").document(postId).update("replies", FieldValue.increment(1))
                            if (p.authorId.isNotBlank() && p.authorId != user.uid) createCommunityNotification(firestore, p.authorId, user.uid, "reply", "${name} replied to your post", postId)
                            draft = ""; replyTo = null
                        }
                        .addOnFailureListener { error = it.localizedMessage ?: "Reply failed" }
                }) { Text("Send") }
            }
        }
    }
}

private data class ReplyItem(
    val id: String,
    val authorId: String,
    val authorName: String,
    val text: String,
    val parentId: String
)

@Composable
private fun ReplyThreadItem(
    item: ReplyItem,
    children: Map<String, List<ReplyItem>>,
    onReply: (ReplyItem) -> Unit,
    depth: Int = 0
) {
    Card(Modifier.fillMaxWidth().padding(start = (depth.coerceAtMost(3) * 18).dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(item.authorName, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text(item.text)
            TextButton(onClick = { onReply(item) }) { Text("Reply") }
            children[item.id]?.take(20)?.forEach { child ->
                ReplyThreadItem(child, children, onReply, depth + 1)
            }
        }
    }
}

@Composable
private fun ReplyDialog(
    post: OnlineCommunityPost,
    firestore: FirebaseFirestore,
    currentUser: com.google.firebase.auth.FirebaseUser?,
    onDismiss: () -> Unit,
    onError: (String) -> Unit
) {
    var reply by remember { mutableStateOf("") }
    var replies by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    DisposableEffect(post.id) {
        val registration = firestore.collection("posts").document(post.id).collection("replies")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) { onError(exception.localizedMessage ?: "Replies load failed"); return@addSnapshotListener }
                replies = snapshot?.documents?.map {
                    (it.getString("authorName") ?: "User") to (it.getString("text") ?: "")
                } ?: emptyList()
            }
        onDispose { registration.remove() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Replies") },
        text = {
            Column {
                if (replies.isEmpty()) Text("No replies yet.")
                replies.takeLast(20).forEach { (name, text) ->
                    Text(name, fontWeight = FontWeight.Bold)
                    Text(text)
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(reply, { if (it.length <= 300) reply = it }, Modifier.fillMaxWidth(), label = { Text("Reply") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val user = currentUser ?: return@TextButton
                val clean = reply.trim()
                if (clean.isBlank()) return@TextButton
                val name = user.displayName?.takeIf { it.isNotBlank() } ?: user.email?.substringBefore("@") ?: "User"
                val data = hashMapOf<String, Any>("authorId" to user.uid, "authorName" to name, "text" to clean, "createdAt" to FieldValue.serverTimestamp())
                firestore.collection("posts").document(post.id).collection("replies").add(data)
                    .addOnSuccessListener {
                        firestore.collection("posts").document(post.id).update("replies", FieldValue.increment(1))
                        if (post.authorId.isNotBlank() && post.authorId != user.uid) {
                            createCommunityNotification(firestore, post.authorId, user.uid, "reply", "${name} replied to your post", post.id)
                        }
                        reply = ""
                    }
                    .addOnFailureListener { onError(it.localizedMessage ?: "Reply failed") }
            }) { Text("Send") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}


private fun createCommunityNotification(
    firestore: FirebaseFirestore,
    recipientUid: String,
    actorUid: String,
    type: String,
    message: String,
    postId: String = ""
) {
    if (recipientUid.isBlank() || actorUid.isBlank() || recipientUid == actorUid) return
    firestore.collection("users").document(recipientUid).collection("notifications").add(
        hashMapOf<String, Any>(
            "actorId" to actorUid,
            "type" to type,
            "message" to message,
            "postId" to postId,
            "read" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
    )
}

@Composable
private fun FollowButton(
    targetUid: String,
    targetName: String,
    currentUid: String,
    firestore: FirebaseFirestore,
    onError: (String) -> Unit
) {
    var following by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(targetUid, currentUid) {
        firestore.collection("users").document(currentUid).collection("following").document(targetUid).get()
            .addOnSuccessListener { following = it.exists(); loaded = true }
            .addOnFailureListener { loaded = true; onError(it.localizedMessage ?: "Follow status failed") }
    }
    TextButton(enabled = loaded, onClick = {
        val myFollowing = firestore.collection("users").document(currentUid).collection("following").document(targetUid)
        val theirFollowers = firestore.collection("users").document(targetUid).collection("followers").document(currentUid)
        firestore.runTransaction { tx ->
            val exists = tx.get(myFollowing).exists()
            if (exists) {
                tx.delete(myFollowing); tx.delete(theirFollowers)
            } else {
                tx.set(myFollowing, hashMapOf("uid" to targetUid, "createdAt" to FieldValue.serverTimestamp()))
                tx.set(theirFollowers, hashMapOf("uid" to currentUid, "createdAt" to FieldValue.serverTimestamp()))
            }
        }.addOnSuccessListener {
            following = !following
            if (following) createCommunityNotification(firestore, targetUid, currentUid, "follow", "${userDisplayName(FirebaseAuth.getInstance().currentUser)} started following you")
        }.addOnFailureListener { onError(it.localizedMessage ?: "Follow failed") }
    }) { Text(if (following) "Following" else "Follow") }
}


private data class CommunityUserSummary(val uid: String, val name: String, val email: String = "")

@Composable
private fun CommunityUserSearchScreen(nav: NavHostController) {
    val db = remember { FirebaseFirestore.getInstance() }
    var query by remember { mutableStateOf("") }
    var users by remember { mutableStateOf<List<CommunityUserSummary>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun searchUsers() {
        loading = true; error = ""
        db.collection("users").limit(100).get()
            .addOnSuccessListener { snap ->
                val q = query.trim().lowercase()
                users = snap.documents.mapNotNull { d ->
                    val n = d.getString("name") ?: return@mapNotNull null
                    val e = d.getString("email") ?: ""
                    CommunityUserSummary(d.id, n, e)
                }.filter { q.isBlank() || it.name.lowercase().contains(q) || it.email.lowercase().contains(q) }
                loading = false
            }
            .addOnFailureListener { loading = false; error = it.localizedMessage ?: "Search failed" }
    }

    LaunchedEffect(Unit) { searchUsers() }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Find Aspirants", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Search name or email") }, singleLine = true,
            trailingIcon = { TextButton(onClick = { searchUsers() }) { Text("Search") } }
        )
        Spacer(Modifier.height(12.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.uid }) { user ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate("community_profile/${user.uid}") }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, null, Modifier.size(38.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(user.name, fontWeight = FontWeight.Bold)
                            if (user.email.isNotBlank()) Text(user.email, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("View")
                    }
                }
            }
        }
    }
}

@Composable
private fun FollowListScreen(nav: NavHostController, uid: String, followingList: Boolean) {
    val db = remember { FirebaseFirestore.getInstance() }
    var users by remember { mutableStateOf<List<CommunityUserSummary>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(uid, followingList) {
        loading = true
        val sub = if (followingList) "following" else "followers"
        db.collection("users").document(uid).collection(sub).get()
            .addOnSuccessListener { snap ->
                val ids = snap.documents.map { it.id }
                if (ids.isEmpty()) { users = emptyList(); loading = false; return@addOnSuccessListener }
                val chunks = ids.chunked(10)
                val found = mutableListOf<CommunityUserSummary>()
                var done = 0
                chunks.forEach { chunk ->
                    db.collection("users").whereIn(com.google.firebase.firestore.FieldPath.documentId(), chunk).get()
                        .addOnSuccessListener { us ->
                            found += us.documents.map { d -> CommunityUserSummary(d.id, d.getString("name") ?: "User", d.getString("email") ?: "") }
                            done++
                            if (done == chunks.size) { users = found; loading = false }
                        }
                        .addOnFailureListener { loading = false; error = it.localizedMessage ?: "Could not load users" }
                }
            }
            .addOnFailureListener { loading = false; error = it.localizedMessage ?: "Could not load list" }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(if (followingList) "Following" else "Followers", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        if (!loading && users.isEmpty() && error.isBlank()) Text(if (followingList) "Not following anyone yet." else "No followers yet.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.uid }) { user ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate("community_profile/${user.uid}") }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, null, Modifier.size(38.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(user.name, fontWeight = FontWeight.Bold)
                            if (user.email.isNotBlank()) Text(user.email, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CommunityProfileScreen(
    uid: String,
    nav: NavHostController? = null,
    onDismiss: (() -> Unit)? = null
) {
    val firestore = remember { FirebaseFirestore.getInstance() }
    val me = FirebaseAuth.getInstance().currentUser?.uid
    var name by remember { mutableStateOf("User") }
    var email by remember { mutableStateOf("") }
    var posts by remember { mutableStateOf(0) }
    var followers by remember { mutableStateOf(0L) }
    var following by remember { mutableStateOf(0L) }
    var error by remember { mutableStateOf("") }
    var avatarUrl by remember { mutableStateOf("") }
    LaunchedEffect(uid) {
        firestore.collection("users").document(uid).get().addOnSuccessListener {
            name = it.getString("name") ?: "User"
            email = it.getString("email") ?: ""
            avatarUrl = it.getString("avatarUrl") ?: ""
        }
        firestore.collection("posts").whereEqualTo("authorId", uid).get().addOnSuccessListener { posts = it.size() }
        firestore.collection("users").document(uid).collection("followers").get().addOnSuccessListener { followers = it.size().toLong() }
        firestore.collection("users").document(uid).collection("following").get().addOnSuccessListener { following = it.size().toLong() }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onDismiss?.invoke() ?: nav?.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Profile", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { nav?.navigate("community_search") }) { Text("Find Users") }
            TextButton(onClick = { nav?.navigate("saved_posts") }) { Text("Saved") }
        }
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (avatarUrl.isNotBlank()) AsyncImage(model = avatarUrl, contentDescription = "Profile photo", modifier = Modifier.size(76.dp))
                else Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(56.dp))
                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (email.isNotBlank()) Text(email, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = { nav?.navigate("user_posts/$uid") }) { StatItem("Posts", posts.toString()) }
                    TextButton(onClick = { nav?.navigate("followers/$uid") }) { StatItem("Followers", followers.toString()) }
                    TextButton(onClick = { nav?.navigate("following/$uid") }) { StatItem("Following", following.toString()) }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { nav?.navigate("user_posts/$uid") }, modifier = Modifier.fillMaxWidth()) {
                    Text("🖼️ View Media & Posts")
                }
                if (me != null && me != uid) {
                    Spacer(Modifier.height(12.dp))
                    FollowButton(targetUid = uid, targetName = name, currentUid = me, firestore = firestore, onError = { error = it })
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable private fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp); Text(label, style = MaterialTheme.typography.labelSmall) }
}


@Composable
private fun SavedPostsScreen(nav: NavHostController) {
    val user = FirebaseAuth.getInstance().currentUser
    val db = remember { FirebaseFirestore.getInstance() }
    var posts by remember { mutableStateOf<List<OnlineCommunityPost>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(user?.uid) {
        if (user == null) return@DisposableEffect onDispose { }
        val reg = db.collection("users").document(user.uid).collection("savedPosts")
            .orderBy("savedAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage ?: "Saved posts load failed"
                    loading = false
                } else {
                    posts = snap?.documents?.map { d ->
                        OnlineCommunityPost(
                            id = d.id,
                            authorId = d.getString("authorId") ?: "",
                            authorName = d.getString("authorName") ?: "User",
                            text = d.getString("text") ?: "",
                            likes = 0, likedBy = emptyList(), replies = 0,
                            createdAt = d.getTimestamp("savedAt")?.toDate()?.time ?: 0L,
                            imageUrl = d.getString("imageUrl") ?: "",
                            videoUrl = d.getString("videoUrl") ?: ""
                        )
                    } ?: emptyList()
                    loading = false
                }
            }
        onDispose { reg.remove() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("🔖 Saved Posts", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        if (!loading && posts.isEmpty() && error.isBlank()) {
            Text("अजून saved posts नाहीत.")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(posts, key = { it.id }) { post ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(post.authorName, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text(post.text)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            db.collection("users").document(user!!.uid).collection("savedPosts")
                                .document(post.id).delete()
                        }) { Text("Remove from Saved") }
                    }
                }
            }
        }
    }
}

@Composable
private fun UserPostsScreen(nav: NavHostController, uid: String) {
    val db = remember { FirebaseFirestore.getInstance() }
    var posts by remember { mutableStateOf<List<OnlineCommunityPost>>(emptyList()) }
    var name by remember { mutableStateOf("User") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(uid) {
        val reg = db.collection("posts").whereEqualTo("authorId", uid).limit(50)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage ?: "Posts load failed"
                    loading = false
                } else {
                    posts = snap?.documents?.map(::postFromSnapshot)
                        ?.sortedByDescending { it.createdAt } ?: emptyList()
                    loading = false
                }
            }
        onDispose { reg.remove() }
    }
    LaunchedEffect(uid) {
        db.collection("users").document(uid).get().addOnSuccessListener {
            name = it.getString("name") ?: "User"
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("$name • Posts", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        if (!loading && posts.isEmpty() && error.isBlank()) Text("या user ने अजून post केलेल्या नाहीत.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(posts, key = { it.id }) { post ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(post.text)
                        Spacer(Modifier.height(8.dp))
                        Text("❤️ ${post.likes}   💬 ${post.replies}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportDialog(
    post: OnlineCommunityPost,
    firestore: FirebaseFirestore,
    currentUser: com.google.firebase.auth.FirebaseUser?,
    onDismiss: () -> Unit,
    onError: (String) -> Unit
) {
    val reasons = listOf("Spam", "Abusive content", "Wrong information", "Other")
    var selected by remember { mutableStateOf(reasons.first()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Report post") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Reason select करा:")
                reasons.forEach { reason ->
                    Row(Modifier.fillMaxWidth().clickable { selected = reason }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected == reason, onClick = { selected = reason })
                        Text(reason)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val uid = currentUser?.uid ?: return@TextButton
                val data = hashMapOf<String, Any>(
                    "postId" to post.id, "reporterId" to uid, "reason" to selected,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                firestore.collection("reports").add(data)
                    .addOnSuccessListener { onDismiss() }
                    .addOnFailureListener { onError(it.localizedMessage ?: "Report failed") }
            }) { Text("Report") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun OnlineProfileCard(user: com.google.firebase.auth.FirebaseUser?, firestore: FirebaseFirestore, onAdmin: () -> Unit) {
    var name by remember { mutableStateOf(userDisplayName(user)) }
    var saved by remember { mutableStateOf(false) }
    val uid = user?.uid
    LaunchedEffect(uid) {
        if (uid != null) firestore.collection("users").document(uid).get().addOnSuccessListener {
            name = it.getString("name") ?: userDisplayName(user)
        }
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).background(Color(0xFF1264E8), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) { Text("👤", fontSize = 25.sp) }
                Spacer(Modifier.width(10.dp))
                Column { Text("Community Profile", fontWeight = FontWeight.Bold); Text(user?.email ?: "") }
            }
            OutlinedTextField(name, { if (it.length <= 30) name = it }, Modifier.fillMaxWidth(), label = { Text("Display name") }, singleLine = true)
            Button(onClick = {
                if (uid == null || name.trim().isBlank()) return@Button
                firestore.collection("users").document(uid).set(
                    mapOf("name" to name.trim(), "email" to (user.email ?: "")),
                    com.google.firebase.firestore.SetOptions.merge()
                ).addOnSuccessListener { saved = true }
            }, Modifier.fillMaxWidth()) { Text(if (saved) "Saved ✓" else "Save Profile") }
            if (uid == ADMIN_UID) {
                OutlinedButton(onClick = onAdmin, Modifier.fillMaxWidth()) { Icon(Icons.Default.AdminPanelSettings, null); Spacer(Modifier.width(6.dp)); Text("Admin Moderation") }
            }
            OutlinedButton(onClick = { FirebaseAuth.getInstance().signOut() }, Modifier.fillMaxWidth()) { Text("Sign Out") }
        }
    }
}


@Composable
private fun AdminModerationScreen(onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var reports by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val reg = db.collection("reports").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { snap, e ->
                if (e != null) error = e.localizedMessage ?: "Load failed"
                else reports = snap?.documents?.map { (it.id) to ((it.getString("reason") ?: "Report") + " • post=" + (it.getString("postId") ?: "")) } ?: emptyList()
            }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Text("Admin Moderation", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        Text("Reports: ${reports.size}", fontWeight = FontWeight.Bold)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        LazyColumn { items(reports, key = { it.first }) { item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(item.second, Modifier.weight(1f))
                    TextButton(onClick = { db.collection("reports").document(item.first).delete() }) { Text("Dismiss") }
                }
            }
        }}
    }
}

@Composable
fun DailyAffairsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<DailyAffair>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            loading = true
            error = false
            val result = withContext(Dispatchers.IO) { fetchDailyAffairs() }
            items = result
            error = result.isEmpty()
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("📰 Daily Affairs", style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold)
                Text("Live headlines for Police Bharti preparation",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton({ refresh() }) { Text("Refresh") }
        }

        Spacer(Modifier.height(10.dp))

        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else if (error) {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Live news load झाली नाही. Internet connection तपासा आणि Refresh करा.",
                    Modifier.padding(16.dp)
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(items) { item ->
                    Card(Modifier.fillMaxWidth().clickable { openNews(context, item.link) }) {
                        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold)
                            Text(item.source.ifBlank { "News source" },
                                style = MaterialTheme.typography.labelMedium)
                            if (item.published.isNotBlank()) {
                                Text(item.published,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("Article उघडा ↗",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun Study(onQuiz:(String)->Unit, onMocks:()->Unit) {
    var selected by remember{mutableStateOf<StudyTopic?>(null)}
    if(selected==null) Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("अभ्यास",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("रोज थोडं, सातत्याने मोठी तयारी.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onMocks,Modifier.fillMaxWidth()){Text("📝 Mock Tests")}
        studyTopics.forEach{topic->Card(Modifier.fillMaxWidth().clickable{selected=topic}){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(topic.title,style=MaterialTheme.typography.titleLarge);Text(topic.subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("${topic.bullets.size} मुख्य topics",style=MaterialTheme.typography.labelMedium)}
        }}
    } else {
        val topic=selected!!
        if(topic.title=="गणित") {
            MathsSyllabusScreen(onBack={selected=null}, onQuiz=onQuiz)
        } else if(topic.title=="GK / GS") {
            GkGsSyllabusScreen(onBack={selected=null}, onQuiz=onQuiz)
        } else {
            Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                TextButton({selected=null}){Text("← अभ्यासाकडे")}
                Text(topic.title,style=MaterialTheme.typography.headlineSmall)
                topic.bullets.forEachIndexed{i,b->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(15.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Text("${i+1}.");Text(b)}}}
                Button({onQuiz(topic.title)},Modifier.fillMaxWidth()){Text("या विषयाचा MCQ सराव")}
            }
        }
    }
}

@Composable
fun MathsSyllabusScreen(onBack:()->Unit, onQuiz:(String)->Unit) {
    var expanded by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onBack){Text("← अभ्यासाकडे")}
        Text("गणित • पूर्ण अभ्यासक्रम",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text("46 chapters • प्रत्येक chapter मधील types",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(mathsSyllabus) { topic ->
                val isOpen=expanded==topic.no
                Card(Modifier.fillMaxWidth().clickable{expanded=if(isOpen)null else topic.no}) {
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${topic.no}. ${topic.title}",fontWeight=FontWeight.Bold)
                                Text(topic.english,color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.labelMedium)
                            }
                            Text(if(isOpen) "▲" else "▼")
                        }
                        Text("${topic.types.size} types",style=MaterialTheme.typography.labelMedium)
                        if(isOpen) {
                            topic.types.forEachIndexed { i, type ->
                                Row(Modifier.fillMaxWidth().padding(top=3.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Text("${i+1}.",fontWeight=FontWeight.Bold)
                                    Text(type,Modifier.weight(1f))
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton({onQuiz("गणित")},Modifier.fillMaxWidth()) { Text("📝 गणित MCQ सराव") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GkGsSyllabusScreen(onBack:()->Unit, onQuiz:(String)->Unit) {
    var expanded by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onBack){Text("← अभ्यासाकडे")}
        Text("GK / GS • पूर्ण अभ्यासक्रम",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text("28 sections • प्रत्येक section मधील topics",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(gkGsSyllabus) { topic ->
                val isOpen=expanded==topic.no
                Card(Modifier.fillMaxWidth().clickable{expanded=if(isOpen)null else topic.no}) {
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${topic.no}. ${topic.title}",fontWeight=FontWeight.Bold)
                                Text(topic.english,color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.labelMedium)
                            }
                            Text(if(isOpen) "▲" else "▼")
                        }
                        Text("${topic.types.size} topics",style=MaterialTheme.typography.labelMedium)
                        if(isOpen) {
                            topic.types.forEachIndexed { i, type ->
                                Row(Modifier.fillMaxWidth().padding(top=3.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Text("${i+1}.",fontWeight=FontWeight.Bold)
                                    Text(type,Modifier.weight(1f))
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton({onQuiz("GK/GS")},Modifier.fillMaxWidth()) { Text("📝 GK / GS MCQ सराव") }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun MockTests(onStart:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Mock Tests",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("30 sec/question • Full syllabus + subject + topic practice.",color=MaterialTheme.colorScheme.onSurfaceVariant)

        Text("Subject Mocks",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        mockTests.forEach { test ->
            Card(Modifier.fillMaxWidth().clickable{onStart(test.category)}) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text(test.title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text(test.subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${test.count} questions • 30 sec/question",style=MaterialTheme.typography.labelMedium)
                }
            }
        }

        Text("Topic-wise Practice",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        topicMocks.forEach { test ->
            Card(Modifier.fillMaxWidth().clickable{onStart(test.category)}) {
                Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text("🎯",style=MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(test.title,fontWeight=FontWeight.Bold)
                        Text(test.subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun Quiz(category:String,onDone:()->Unit) {
    val context=LocalContext.current
    val filterParts = remember(category) { category.split("::", limit = 2) }
    val filtered=remember(category){
        when {
            category=="All" -> questions
            filterParts.firstOrNull()=="TOPIC" -> questions.filter{it.topic==filterParts.getOrElse(1){""}}.ifEmpty{questions}
            else -> questions.filter{it.category==category}.ifEmpty{questions}
        }
    }
    var index by remember{mutableStateOf(0)}
    var answers by remember{mutableStateOf(List(filtered.size){-1})}
    var seconds by remember{mutableStateOf(filtered.size*30)}
    var finished by remember{mutableStateOf(false)}
    LaunchedEffect(finished){while(!finished&&seconds>0){delay(1000);seconds--};if(!finished&&seconds==0)finished=true}
    if(finished){
        val score=answers.indices.count{answers[it]==filtered[it].answer}
        val attempted=answers.count{it>=0}
        LaunchedEffect(Unit){
            db.quizDao().insert(QuizResult(category = category, score = score, total = filtered.size))
            awardXp(context, if (score == filtered.size) 20 else 10)
            val wrongIds = answers.indices.filter{answers[it] != filtered[it].answer}.map{filtered[it].id}.toSet()
            context.lakshyaDataStore.edit { prefs ->
                val old = prefs[MISTAKE_IDS] ?: emptySet()
                prefs[MISTAKE_IDS] = (old + wrongIds).take(100).toSet()
            }
        }
        Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
            Text("Quiz Result",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            Text("$score / ${filtered.size}",style=MaterialTheme.typography.displaySmall)
            Text("${if(filtered.isEmpty())0 else score*100/filtered.size}% • Attempted $attempted/${filtered.size}")
            Button({onDone()},Modifier.fillMaxWidth()){Text("Back")}
        }
        return
    }
    val q=filtered[index]
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Question ${index+1}/${filtered.size}");Text(String.format(Locale.getDefault(),"%02d:%02d",seconds/60,seconds%60))}
        LinearProgressIndicator(progress={(index+1f)/filtered.size},modifier=Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Text(q.category,style=MaterialTheme.typography.labelLarge)
            Text(q.question,style=MaterialTheme.typography.titleLarge)
            q.options.forEachIndexed{i,opt->OutlinedButton({answers=answers.toMutableList().also{it[index]=i}},Modifier.fillMaxWidth()){Text("${('A'.code+i).toChar()}. $opt"+if(answers[index]==i)" ✓" else "")}}
        }}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton({if(index>0)index--},enabled=index>0,modifier=Modifier.weight(1f)){Text("Previous")}
            Button({if(index<filtered.lastIndex)index++ else finished=true},Modifier.weight(1f)){Text(if(index==filtered.lastIndex)"Finish" else "Next")}
        }
    }
}

@Composable
fun Ground() {
    val scope=rememberCoroutineScope()
    var event by remember{mutableStateOf("1600m")}
    var value by remember{mutableStateOf("")}
    var history by remember{mutableStateOf(listOf<GroundResult>())}
    LaunchedEffect(Unit){history=db.groundDao().all().first()}
    val rows=history.filter{it.event==event}
    val best=if(event=="Shot Put") rows.mapNotNull{it.value.toDoubleOrNull()}.maxOrNull()?.let{"%.2f m".format(it)}
    else rows.mapNotNull{parseTimeSeconds(it.value)}.minOrNull()?.let(::formatTime)
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Ground Tracker",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("1600m","100m","Shot Put").forEach{e->FilterChip(event==e,{event=e;value=""},{Text(e)})}}
        OutlinedTextField(value,{value=it.filter{c->c.isDigit()||c=='.'||c==':'}} ,label={Text(if(event=="Shot Put")"Distance (m)" else "Time (sec)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Button({if(value.isNotBlank())scope.launch{db.groundDao().insert(GroundResult(event=event,value=value));value="";history=db.groundDao().all().first()}},enabled=value.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text("Save Performance")}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Personal Best",style=MaterialTheme.typography.titleMedium);Text(best?:"No record yet",style=MaterialTheme.typography.headlineSmall);Text("${rows.size} saved attempt(s)",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
        Text("Recent History",style=MaterialTheme.typography.titleLarge)
        LazyColumn{items(rows.take(8)){r->ListItem({Text(r.value+(if(event=="Shot Put")" m" else " sec"))},{Text(SimpleDateFormat("dd MMM, HH:mm",Locale.getDefault()).format(Date(r.timestamp)))})}}
    }
}

@Composable
fun Progress() {
    val ground=remember{mutableStateListOf<GroundResult>()}
    val quizzes=remember{mutableStateListOf<QuizResult>()}
    LaunchedEffect(Unit){ground.addAll(db.groundDao().all().first());quizzes.addAll(db.quizDao().all().first())}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Progress",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        listOf("1600m","100m","Shot Put").forEach{event->
            val rows=ground.filter{it.event==event};val vals=rows.mapNotNull{if(event=="Shot Put")it.value.toDoubleOrNull() else parseTimeSeconds(it.value)}
            val best=if(event=="Shot Put")vals.maxOrNull() else vals.minOrNull()
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                Text(event,style=MaterialTheme.typography.titleLarge);Text("Personal Best: "+(if(best==null)"—" else if(event=="Shot Put")"%.2f m".format(best) else formatTime(best)));Text("${rows.size} attempts",color=MaterialTheme.colorScheme.onSurfaceVariant)
            }}
        }
        val total=quizzes.sumOf{it.total};val score=quizzes.sumOf{it.score};val pct=if(total>0)score*100/total else 0
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Study Performance",style=MaterialTheme.typography.titleLarge);Text("${quizzes.size} quiz attempts");Text("Overall MCQ accuracy: $pct%");LinearProgressIndicator(progress={pct/100f},modifier=Modifier.fillMaxWidth())}}
    }
}

private fun calculateStreak(ts:List<Long>):Int{
    val set=ts.map(::dateKey).toSet();var d=Calendar.getInstance();var streak=0
    while(set.contains(SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(d.time))){streak++;d.add(Calendar.DAY_OF_YEAR,-1)}
    return streak
}

@Composable
fun Profile(nav:NavHostController,requestPermission:()->Unit){
    val scope=rememberCoroutineScope();val context=LocalContext.current
    var ground by remember{mutableStateOf(listOf<GroundResult>())};var quizzes by remember{mutableStateOf(listOf<QuizResult>())}
    LaunchedEffect(Unit){ground=db.groundDao().all().first();quizzes=db.quizDao().all().first()}
    val streak=calculateStreak(ground.map{it.timestamp}+quizzes.map{it.timestamp})
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Profile",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        OnlineProfileCard(FirebaseAuth.getInstance().currentUser, FirebaseFirestore.getInstance()) { nav.navigate("admin") }
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Current Streak",style=MaterialTheme.typography.titleMedium);Text("$streak day 🔥",style=MaterialTheme.typography.headlineSmall);Text("Quiz: ${quizzes.size} • Ground: ${ground.size}",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
        Button({nav.navigate("daily")},Modifier.fillMaxWidth()){Text("🎯 Daily Goals")}
        OutlinedButton({nav.navigate("smart")},Modifier.fillMaxWidth()){Text("🧠 Smart Practice")}
        OutlinedButton({nav.navigate("rank")},Modifier.fillMaxWidth()){Text("🏆 Rank & Points")}
        OutlinedButton({nav.navigate("analytics")},Modifier.fillMaxWidth()){Text("📊 Analytics Dashboard")}
        OutlinedButton({nav.navigate("missions")},Modifier.fillMaxWidth()){Text("🔥 Daily Missions")}
        OutlinedButton({nav.navigate("planner")},Modifier.fillMaxWidth()){Text("📅 Study Planner")}
        OutlinedButton({nav.navigate("mistakes")},Modifier.fillMaxWidth()){Text("📕 Mistake Book")}
        OutlinedButton({nav.navigate("reminders")},Modifier.fillMaxWidth()){Text("🔔 Reminder Settings")}
        Text("Achievements",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        val bestQuiz=quizzes.maxOfOrNull{if(it.total>0)it.score*100/it.total else 0}?:0
        listOf(
            "🎯 First Step" to (quizzes.isNotEmpty()),"🧠 Quiz Starter" to (quizzes.size>=5),
            "🏃 Ground Ready" to (ground.isNotEmpty()),"🔥 Training Mode" to (ground.size>=10),
            "🏆 80% Club" to (bestQuiz>=80),"⚡ 3 Day Streak" to (streak>=3),"👑 7 Day Streak" to (streak>=7)
        ).forEach{(name,ok)->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=if(ok)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)){Text(name+(if(ok)" ✓" else " 🔒"),Modifier.padding(14.dp))}}
    }
}


@Composable
fun QuestionReview(q: Question, selected: Int?) {
    val correct = selected == q.answer
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(q.topic, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary)
            Text(q.question, fontWeight = FontWeight.Bold)
            Text("तुमचे उत्तर: " + (selected?.let { q.options.getOrNull(it) } ?: "उत्तर दिले नाही"),
                color = if (correct) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.error)
            Text("योग्य उत्तर: ${q.options[q.answer]}", fontWeight = FontWeight.SemiBold)
            Text(q.explanation)
        }
    }
}

@Composable
fun MistakeBook(nav: NavHostController) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var ids by remember{mutableStateOf(setOf<String>())}
    LaunchedEffect(Unit){
        ids=context.lakshyaDataStore.data.first()[MISTAKE_IDS] ?: emptySet()
    }
    val mistakes=questions.filter{ids.contains(it.id)}

    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Text("Mistake Book",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            Text("${mistakes.size}",style=MaterialTheme.typography.titleLarge)
        }
        Text("चुकीचे झालेले प्रश्न इथे save होतात. पुन्हा practice करा.",color=MaterialTheme.colorScheme.onSurfaceVariant)

        if(mistakes.isEmpty()){
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("🎉 अजून mistakes नाहीत!",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text("Mock Test सोडवा. चुकीचे प्रश्न आपोआप इथे येतील.")
                }
            }
        } else {
            LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.weight(1f)){
                items(mistakes){q->
                    Card(Modifier.fillMaxWidth()){
                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                            Text("${q.category} • ${q.topic}",style=MaterialTheme.typography.labelLarge)
                            Text(q.question,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                            Text("योग्य उत्तर: ${q.options[q.answer]}")
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton({
                    scope.launch{
                        context.lakshyaDataStore.edit{it[MISTAKE_IDS]=emptySet()}
                        ids=emptySet()
                    }
                },Modifier.weight(1f)){Text("Clear Book")}
                Button({nav.navigate("quiz/All")},Modifier.weight(1f)){Text("Practice Again")}
            }
        }
    }
}




private suspend fun awardXp(context: android.content.Context, amount: Int) {
    context.lakshyaDataStore.edit { prefs ->
        prefs[LEADERBOARD_POINTS] = (prefs[LEADERBOARD_POINTS] ?: 0) + amount
    }
}




@Composable
fun StudyPlanner(nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val days = listOf("सोम", "मंगळ", "बुध", "गुरु", "शुक्र", "शनि", "रवि")
    val defaultPlan = setOf("सोम", "मंगळ", "बुध", "गुरु", "शुक्र", "शनि")
    var selected by remember { mutableStateOf(defaultPlan) }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val prefs = context.lakshyaDataStore.data.first()
        selected = prefs[PLANNER_DAYS] ?: defaultPlan
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("📅 Study Planner",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold)
        Text("तुमच्या आठवड्याचा simple preparation plan सेट करा.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Weekly Practice Days",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)

                days.forEach { day ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = day in selected,
                            onCheckedChange = {
                                selected = if (it) selected + day else selected - day
                                saved = false
                            }
                        )
                        Text(day)
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Suggested Routine", fontWeight = FontWeight.Bold)
                Text("सोम: Marathi + Maths")
                Text("मंगळ: Reasoning + 100m practice")
                Text("बुध: GK/GS + revision")
                Text("गुरु: Marathi + Mock Test")
                Text("शुक्र: Maths + Reasoning")
                Text("शनि: Full Mock + Ground tracking")
                Text("रवि: Light revision / recovery")
            }
        }

        Button(
            onClick = {
                scope.launch {
                    context.lakshyaDataStore.edit { it[PLANNER_DAYS] = selected }
                    saved = true
                }
            },
            Modifier.fillMaxWidth()
        ) {
            Text(if (saved) "✅ Plan Saved" else "Save Weekly Plan")
        }

        OutlinedButton(
            onClick = { nav.navigate("missions") },
            Modifier.fillMaxWidth()
        ) { Text("🔥 Open Daily Missions") }
    }
}

@Composable
fun DailyMissions(nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var points by remember { mutableStateOf(0) }
    var xpGoal by remember { mutableStateOf(50) }
    var mcqDone by remember { mutableStateOf(0) }
    var groundDone by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val p = context.lakshyaDataStore.data.first()
        points = p[LEADERBOARD_POINTS] ?: 0
        xpGoal = p[DAILY_XP_GOAL] ?: 50
        mcqDone = db.quizDao().all().first()
            .count { System.currentTimeMillis() - it.timestamp < 24L * 60 * 60 * 1000 }
        groundDone = db.groundDao().all().first()
            .any { System.currentTimeMillis() - it.timestamp < 24L * 60 * 60 * 1000 }
    }

    val earnedToday = (mcqDone * 10) + if (groundDone) 15 else 0
    val progress = (earnedToday.toFloat() / xpGoal).coerceIn(0f, 1f)
    val complete = earnedToday >= xpGoal

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🔥 Daily Missions",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold)
        Text("आजची छोटी targets पूर्ण करा आणि XP वाढवा.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (complete) "🏆 Daily Mission Complete!" else "Today's XP")
                Text("$earnedToday / $xpGoal XP",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold)
                LinearProgressIndicator(
                    progress = { progress },
                    Modifier.fillMaxWidth()
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Today's Checklist",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)

                Text("${if (mcqDone > 0) "✅" else "⬜"} Quiz practice — +10 XP each")
                Text("${if (groundDone) "✅" else "⬜"} Ground attempt — +15 XP")
                Text("${if (complete) "✅" else "⬜"} Daily XP target — $xpGoal XP")
            }
        }

        Text("🎯 Set Daily XP Target", style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold)

        Slider(
            value = xpGoal.toFloat(),
            onValueChange = { xpGoal = it.toInt() },
            valueRange = 20f..150f,
            steps = 12
        )
        Text("$xpGoal XP")

        Button(
            onClick = {
                scope.launch {
                    context.lakshyaDataStore.edit { it[DAILY_XP_GOAL] = xpGoal }
                }
            },
            Modifier.fillMaxWidth()
        ) {
            Text("Save Daily Target")
        }

        OutlinedButton(
            onClick = { nav.navigate("analytics") },
            Modifier.fillMaxWidth()
        ) { Text("📊 View Analytics") }
    }
}

@Composable
fun AnalyticsDashboard(nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var quizResults by remember { mutableStateOf<List<QuizResult>>(emptyList()) }
    var groundResults by remember { mutableStateOf<List<GroundResult>>(emptyList()) }

    LaunchedEffect(Unit) {
        quizResults = db.quizDao().all().first()
        groundResults = db.groundDao().all().first()
    }

    val quizTotal = quizResults.sumOf { it.total }
    val quizScore = quizResults.sumOf { it.score }
    val accuracy = if (quizTotal == 0) 0 else (quizScore * 100 / quizTotal)
    val best1600 = groundResults.filter { it.event == "1600m" }.mapNotNull { parseTimeSeconds(it.value) }.minOrNull()
    val best100 = groundResults.filter { it.event == "100m" }.mapNotNull { parseTimeSeconds(it.value) }.minOrNull()
    val bestShot = groundResults.filter { it.event == "Shot Put" }.mapNotNull { it.value.toDoubleOrNull() }.maxOrNull()

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("📊 Analytics Dashboard",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold)
        Text("तुमची study + ground performance एकाच ठिकाणी.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Quiz Attempts", style = MaterialTheme.typography.labelMedium)
                    Text("${quizResults.size}", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold)
                }
            }
            Card(Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Accuracy", style = MaterialTheme.typography.labelMedium)
                    Text("$accuracy%", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold)
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🎯 Ground Personal Bests",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                Text("1600m: ${best1600?.let { formatTime(it) } ?: "—"}")
                Text("100m: ${best100?.let { formatTime(it) } ?: "—"}")
                Text("Shot Put: ${bestShot?.let { String.format("%.2f", it) } ?: "—"}")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("📅 Recent Activity",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                if (quizResults.isEmpty() && groundResults.isEmpty()) {
                    Text("अजून data नाही. Quiz किंवा Ground attempt सुरू करा.")
                } else {
                    quizResults.takeLast(5).reversed().forEach {
                        Text("📝 ${it.category}: ${it.score}/${it.total}")
                    }
                    groundResults.takeLast(5).reversed().forEach {
                        Text("🏃 ${it.event}: ${if (it.event == "Shot Put") String.format("%.2f", it.value.toDoubleOrNull() ?: 0.0) else formatTime(parseTimeSeconds(it.value) ?: 0.0)}")
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("💡 Next Focus", fontWeight = FontWeight.Bold)
                Text(
                    when {
                        accuracy < 60 -> "MCQ accuracy वाढवण्यासाठी Mistake Book revise करा."
                        accuracy < 80 -> "80% Club साठी रोज एक focused mock द्या."
                        best1600 == null -> "1600m चा पहिला tracked attempt नोंदवा."
                        else -> "Consistency कायम ठेवा आणि Personal Best सुधारण्यावर focus करा."
                    }
                )
            }
        }
    }
}

@Composable
fun RankSystem(nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var points by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("खाकी योद्धा") }

    LaunchedEffect(Unit) {
        val p = context.lakshyaDataStore.data.first()
        points = p[LEADERBOARD_POINTS] ?: 0
        name = p[LEADERBOARD_NAME] ?: "खाकी योद्धा"
    }

    val rank = when {
        points >= 1000 -> "🏆 Legend"
        points >= 700 -> "🥇 Elite"
        points >= 450 -> "🥈 Pro"
        points >= 250 -> "🥉 Advanced"
        points >= 100 -> "⭐ Starter"
        else -> "🌱 Beginner"
    }
    val next = when {
        points >= 1000 -> 1000
        points >= 700 -> 1000
        points >= 450 -> 700
        points >= 250 -> 450
        points >= 100 -> 250
        else -> 100
    }
    val previous = when {
        points >= 1000 -> 1000
        points >= 700 -> 700
        points >= 450 -> 450
        points >= 250 -> 250
        points >= 100 -> 100
        else -> 0
    }
    val progress = if (next == previous) 1f
        else ((points - previous).toFloat() / (next - previous)).coerceIn(0f, 1f)

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Rank & Points", style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold)
        Text("तुमच्या अभ्यासाच्या consistency वर आधारित local rank.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(rank, style = MaterialTheme.typography.headlineSmall)
                Text("$points XP", style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth())
                Text("$points / $next XP", style = MaterialTheme.typography.labelMedium)
            }
        }

        Text("XP कसा मिळेल?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        listOf(
            "📝 Quiz पूर्ण करा — +10 XP",
            "🎯 Mock Test — +20 XP",
            "🏃 Ground attempt — +15 XP",
            "🔥 Daily goal पूर्ण — +25 XP"
        ).forEach {
            Card(Modifier.fillMaxWidth()) {
                Text(it, Modifier.padding(15.dp))
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🏅 Rank Levels", fontWeight = FontWeight.Bold)
                Text("🌱 Beginner 0 • ⭐ Starter 100 • 🥉 Advanced 250")
                Text("🥈 Pro 450 • 🥇 Elite 700 • 🏆 Legend 1000+")
            }
        }
    }
}

@Composable
fun SmartPractice(nav: NavHostController) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Smart Practice", style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold)
        Text("तुमच्या Mistake Book वर आधारित revision workflow.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(Modifier.fillMaxWidth().clickable { nav.navigate("mistakes") }) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("📕 Mistake Revision", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                Text("चुकीचे झालेले प्रश्न पुन्हा पाहा आणि योग्य उत्तराचे explanation वाचा.")
            }
        }

        Card(Modifier.fillMaxWidth().clickable { nav.navigate("quiz/All") }) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("⚡ Quick Mixed Practice", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                Text("सर्व विषयांचा timed mixed test.")
            }
        }

        Card(Modifier.fillMaxWidth().clickable { nav.navigate("mocks") }) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("🎯 Topic Practice", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold)
                Text("Topic-wise tests मधून weak areas वर सराव करा.")
            }
        }
    }
}

@Composable
fun DailyGoals(){
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    var mcq by remember{mutableStateOf(20)};var ground by remember{mutableStateOf(false)};var saved by remember{mutableStateOf(false)}
    LaunchedEffect(Unit){val p=context.lakshyaDataStore.data.first();mcq=p[DAILY_MCQ_GOAL]?:20;ground=p[DAILY_GROUND_GOAL]?:false}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Daily Goals",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("MCQ Goal",style=MaterialTheme.typography.titleLarge);Text("$mcq questions/day");Slider(value=mcq.toFloat(), onValueChange={mcq=it.toInt()}, valueRange=5f..100f, steps=18)}}
        Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Ground Training",style=MaterialTheme.typography.titleLarge);Text("आज training planned?",color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(ground,{ground=it})}}
        Button({scope.launch{context.lakshyaDataStore.edit{it[DAILY_MCQ_GOAL]=mcq;it[DAILY_GROUND_GOAL]=ground};saved=true}},Modifier.fillMaxWidth()){Text(if(saved)"Saved ✓" else "Save Daily Goals")}
    }
}

@Composable
fun ReminderSettings(requestPermission:()->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    var enabled by remember{mutableStateOf(true)};var hour by remember{mutableStateOf(19)};var minute by remember{mutableStateOf(0)}
    LaunchedEffect(Unit){val p=context.lakshyaDataStore.data.first();enabled=p[REMINDER_ENABLED]?:false;hour=p[REMINDER_HOUR]?:19;minute=p[REMINDER_MINUTE]?:0}
    fun persist(){scope.launch{context.lakshyaDataStore.edit{it[REMINDER_ENABLED]=enabled;it[REMINDER_HOUR]=hour;it[REMINDER_MINUTE]=minute}}}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Reminders",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Daily Reminder",style=MaterialTheme.typography.titleLarge);Text(String.format(Locale.getDefault(),"%02d:%02d",hour,minute))};Switch(enabled,{enabled=it;if(it){scheduleDailyReminder(context,hour,minute);requestPermission()}else cancelDailyReminder(context);persist()})}}
        OutlinedButton({
            TimePickerDialog(context, { _, h, m ->
                hour=h; minute=m
                if(enabled) scheduleDailyReminder(context,hour,minute)
                persist()
            }, hour, minute, true).show()
        },Modifier.fillMaxWidth()){Text("🕒 Change reminder time")}
        Text("Default: 7:00 PM • Android may deliver slightly later to save battery.",color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
