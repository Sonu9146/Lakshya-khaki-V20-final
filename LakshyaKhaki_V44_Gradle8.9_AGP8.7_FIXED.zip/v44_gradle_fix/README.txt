Lakshya Khaki V44 Gradle compatibility fix

Replace/add these files in the Android project:
1. gradle/wrapper/gradle-wrapper.properties
2. build.gradle.kts
3. .github/workflows/build-apk.yml

Versions:
- Gradle: 8.7
- Android Gradle Plugin: 8.5.2
- Kotlin: 2.0.21
- KSP: 2.0.21-1.0.28
- Compose Kotlin plugin: 2.0.21
- Google Services plugin: 4.4.3

Note: This ZIP contains the corrected setup files, not the full V44 Android source project.
