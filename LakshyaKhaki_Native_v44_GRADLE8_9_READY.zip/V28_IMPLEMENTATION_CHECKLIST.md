# V28 checklist

- [ ] Create Firebase project
- [ ] Add Android app package `com.lakshyakhaki.app`
- [ ] Add `google-services.json` to `app/`
- [ ] Enable Firebase Authentication
- [ ] Enable Cloud Firestore
- [ ] Replace local Community state with Firestore repository
- [ ] Add realtime snapshot listener
- [ ] Add replies
- [ ] Add UID-based likes
- [ ] Add ownership checks
- [ ] Test with two devices/accounts
