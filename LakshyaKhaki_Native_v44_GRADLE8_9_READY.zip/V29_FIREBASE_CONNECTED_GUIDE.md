# Lakshya Khaki V29 — Firebase Connected

Firebase Android configuration has been added for package:
`com.lakshyakhaki.app`

## Added
- `app/google-services.json`
- Google Services Gradle plugin
- Firebase project/app configuration from the supplied Firebase config
- V29 implementation guide

## Next in Firebase Console
1. Enable Authentication (start with Email/Password).
2. Create Cloud Firestore database.
3. Add the Community collections described in V28.
4. Add authenticated-user security rules.
5. Build and test on a physical Android device.

## Important
The Android Firebase config contains a client API key. Firebase Android API keys are normally intended for client apps, but access is controlled by Firebase services/rules. Never put a Firebase service-account private key in the Android app.

## Version
- versionName: 3.1.0
- versionCode: 26
