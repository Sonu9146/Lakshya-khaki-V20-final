# V31 — Profiles + Reports + Admin Moderation

Community display profile, post reporting, Firestore reports collection, and admin moderation UI. Replace `PUT_YOUR_ADMIN_FIREBASE_UID_HERE` in MainActivity.kt and firestore.rules with the admin Firebase Auth UID before publishing rules.
