# V44 Build/GitHub Actions Fix

- Kotlin: 2.0.21
- KSP: 2.0.21-1.0.28
- Android Gradle Plugin: 8.7.0
- Gradle runner: 8.7
- JDK: 17
- Removed Kotlin/KSP version injection.
- Workflow automatically finds `settings.gradle.kts` after ZIP extraction and copies that project root to the repository root.
