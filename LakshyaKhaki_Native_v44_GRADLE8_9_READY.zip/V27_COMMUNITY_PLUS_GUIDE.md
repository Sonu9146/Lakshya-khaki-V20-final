# Lakshya Khaki V27 — Community Plus

## Community upgrades
- Local post creation
- Post search
- Like count UI
- Reply count UI placeholder
- Delete action
- Report action placeholder
- User label for own posts
- Community screen foundation for future Firestore wiring

## Important
V27 keeps the honest offline/local behavior. The like/reply/report actions are UI-level foundations unless Firebase Firestore is wired with the project's `google-services.json` and backend rules.

## Version
- versionName: 2.9.0
- versionCode: 24

## Build
Open in Android Studio and sync Gradle. Use JDK 17 if requested.
