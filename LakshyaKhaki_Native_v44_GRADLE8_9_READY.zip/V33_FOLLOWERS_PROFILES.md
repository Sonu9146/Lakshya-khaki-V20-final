# Lakshya Khaki V33 — Followers, Profiles & Community Alerts

- Community author name opens a Firebase user profile.
- Follow / Following support uses `users/{uid}/following` and `users/{uid}/followers`.
- Profile shows posts, followers and following counts.
- Follow, like and reply create in-app community notification documents.
- Notification Center now listens to community alerts and lets the user mark them read.
- Removed duplicate `admin` navigation route from V32.
- Version: 3.5.0 (versionCode 30).

## Firebase rules
Publish the included `firestore.rules`. For production, relationship writes are best moved to trusted server/Cloud Functions so counts and notifications cannot be manipulated by clients.
