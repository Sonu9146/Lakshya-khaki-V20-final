# Lakshya Khaki V40 — Intro + Login

V40 focuses on the first-run experience and Firebase Authentication.

## Flow

First launch:
Intro splash → Welcome → Create Account / Sign In → Home

Returning user:
Intro splash → Home if already signed in, otherwise Sign In

## Included
- Premium dark navy / blue intro screen
- Lakshya Khaki branding and tagline
- Welcome screen inspired by the supplied reference style
- Get Started and I Already Have an Account actions
- Firebase Email/Password Sign In
- Firebase Email/Password Create Account
- Forgot Password email
- User profile document on signup
- Sign Out from Profile
- Google button UI placeholder; real Google provider/OAuth + SHA configuration is still required

## Note
The project is not compiled in this environment because the Android SDK/Gradle build environment is not installed here. Build in Android Studio to verify the complete project.
