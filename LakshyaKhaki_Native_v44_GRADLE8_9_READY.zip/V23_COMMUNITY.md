# Lakshya Khaki V23 – Community

Added a Twitter/X-style community foundation:
- Home-screen Community card
- Community feed
- Create a post locally
- Like UI
- Reply count UI
- Premium-ready dialog/structure
- Native Jetpack Compose, no WebView

Important: this V23 UI is a local/demo foundation. For real multi-user online posts, replies and likes, connect Firebase/Supabase in the next backend step.
