package com.lakshyakhaki.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CommunityOutboxDao {
    @Insert suspend fun insert(action: PendingCommunityAction): Long
    @Query("SELECT * FROM community_outbox ORDER BY createdAt ASC") suspend fun pending(): List<PendingCommunityAction>
    @Update suspend fun update(action: PendingCommunityAction)
    @Query("DELETE FROM community_outbox WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT COUNT(*) FROM community_outbox") fun count(): Flow<Int>
}
