# Lakshya Khaki V38 — Video Community

Version 4.0.0 / versionCode 35

## Added
- Short-video / video posts in Community
- Video picker and Firebase Storage upload
- Video preview/player in Community feed
- Video playback on Post Detail
- Video media shown in User Posts
- Image and video media are mutually exclusive per post
- Firebase Storage rule for `post_videos/{uid}/...` with authenticated owner write and 50 MB limit
- Kept existing Firebase auth, Firestore, likes, replies, follows, saves, notifications, reports and profiles

## Firebase setup
1. Enable Firebase Storage.
2. Publish `storage.rules`.
3. Keep Firestore rules from the previous version.
4. The app uses the existing `google-services.json`.

## Notes
This is a source ZIP, not a compiled APK. Video playback uses Android's VideoView and controls. Actual upload requires Firebase Storage to be enabled and rules published.
