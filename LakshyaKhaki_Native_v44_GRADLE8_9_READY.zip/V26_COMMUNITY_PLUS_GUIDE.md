# Lakshya Khaki V26 — Community Plus

V26 builds on the Firebase-ready V25 foundation.

## Added
- Community Plus card UI
- Open Community action hook
- Premium-ready dialog
- Cleaner community feature separation for future online rollout
- Keeps Firebase/Auth/Firestore dependencies from V25

## Important
This version does **not** fake real multi-user data. Real likes, replies, profiles, reporting and cloud posts still need Firestore wiring plus Firebase configuration (`google-services.json`).

## Build
Open the project in Android Studio, let Gradle sync, then run:
`app > build > assembleDebug`

If Gradle asks for a JDK, use JDK 17.
