import express from "express";
import { v2 as cloudinary } from "cloudinary";

const app = express();
app.use(express.json());

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

app.post("/delete-media", async (req, res) => {
  try {
    const { public_id, resource_type = "image" } = req.body.public_id
      ? req.body
      : req.query;

    if (!public_id) {
      return res.status(400).json({ result: "error", message: "public_id is required" });
    }

    // IMPORTANT: API secret stays only on this backend, never in the Android APK.
    const result = await cloudinary.uploader.destroy(public_id, {
      resource_type,
      invalidate: true
    });

    return res.json(result);
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      result: "error",
      message: error?.message || "Cloudinary delete failed"
    });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Cloudinary delete backend listening on ${port}`));
