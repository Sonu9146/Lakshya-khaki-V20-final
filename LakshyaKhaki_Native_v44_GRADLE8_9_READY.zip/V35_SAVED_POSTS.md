# Lakshya Khaki V35 — Community Saved Posts & User Post History

Version: 3.7.0 (versionCode 32)

## Added
- 🔖 Save/unsave community posts
- 🔖 Saved Posts screen
- 👤 User profile → Posts count opens that user's post history
- 📝 Public user post history screen
- Saved post metadata stored under `users/{uid}/savedPosts/{postId}`
- Realtime saved-post updates
- Existing Firebase Community, followers, profiles and notifications retained

## Notes
Saved posts store a lightweight copy of the post text/author metadata, so the Saved screen remains useful even if the feed changes. It is not a replacement for the original post document.

Exact Android build was not performed in this environment because Android SDK/Gradle tooling is not installed here. Build/test with Android Studio before release.
