# Lakshya Khaki V28 — Firebase Online Community

V28 prepares the Community feature for real multi-user Firebase integration.

## Firestore collections

### posts/{postId}
- authorUid: string
- authorName: string
- text: string
- createdAt: server timestamp
- likeCount: number
- replyCount: number

### posts/{postId}/replies/{replyId}
- authorUid: string
- authorName: string
- text: string
- createdAt: server timestamp

### posts/{postId}/likes/{uid}
- createdAt: server timestamp

## Recommended flow
1. Sign in with Firebase Authentication.
2. Create posts in Firestore.
3. Listen to posts ordered by `createdAt`.
4. Add replies in the post's `replies` subcollection.
5. Store each user's like as `likes/{uid}` to prevent duplicate likes.
6. Use a transaction/cloud function later to maintain counters.

## Security starting point
Use authenticated users only. Users should only be able to create/update/delete their own posts and replies. Likes should be tied to the authenticated UID.

Do not put Firebase service-account keys inside the Android app.

## Current project status
This source package is a preparation step. It does not contain a real project's `google-services.json`, and it does not pretend that the local demo data is already online.

## Version
- versionName: 3.0.0
- versionCode: 25
